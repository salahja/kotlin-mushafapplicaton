package mm.prayer.muslimmate.model;

import java.util.List;

public class WeatherSave {
    public List<WeatherApp> weatherApps;

    public WeatherSave(List<WeatherApp> weatherApps)
    {
        this.weatherApps = weatherApps;
    }

}