package mm.prayer.muslimmate.interfaces;

import android.view.View;

public interface OnItemClickListener {
    void onItemClick(View v, int position);
}
