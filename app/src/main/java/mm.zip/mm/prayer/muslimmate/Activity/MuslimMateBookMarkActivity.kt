package mm.prayer.muslimmate.Activity

import com.example.mushafconsolidated.Activity.BaseActivity

class MuslimMateBookMarkActivity : BaseActivity() {

}
