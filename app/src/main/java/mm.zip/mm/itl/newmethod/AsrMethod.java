package mm.itl.newmethod;

/**
 * Asr Method
 */
public enum AsrMethod {
    SHAFII, HANAFI
}
