package mm.itl.newmethod;

/**
 * Umm Al-Qura uses an offset instead of an angle
 */
public enum IshaFlag {
    ANGLE, OFFSET
}
