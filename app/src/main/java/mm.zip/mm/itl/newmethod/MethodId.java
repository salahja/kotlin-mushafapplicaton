package mm.itl.newmethod;

public enum MethodId {MWL, ISNA, EGAS, UMAQ, UIS}
