package org.sj.conjugator.fragments;

public class SarfSagheer {
    private String madhi, madhimajhool, mudharay, mudharaymajhool, ismfael, ismmafool, weakness, wazan,
            amrone, amrtwo, amrthree, nahiamrone, nahiamrtwo, nahiamrthree, ismalaone, ismalatwo, ismalathree, zarfone, zarftwo, zarfthree, verbroot, verbtype, wazanname;

    public SarfSagheer(String madhi, String madhimajhool, String mudharay, String mudharaymajhool, String ismfael, String ismmafool, String weakness, String wazan, String amrone, String amrtwo, String amrthree, String nahiamrone, String nahiamrtwo, String nahiamrthree, String ismalaone, String ismalatwo, String ismalathree, String zarfone, String zarftwo, String zarfthree, String verbroot) {
        this.madhi = madhi;
        this.madhimajhool = madhimajhool;
        this.mudharay = mudharay;
        this.mudharaymajhool = mudharaymajhool;
        this.ismfael = ismfael;
        this.ismmafool = ismmafool;
        this.weakness = weakness;
        this.wazan = wazan;
        this.amrone = amrone;
        this.amrtwo = amrtwo;
        this.amrthree = amrthree;
        this.nahiamrone = nahiamrone;
        this.nahiamrtwo = nahiamrtwo;
        this.nahiamrthree = nahiamrthree;
        this.ismalaone = ismalaone;
        this.ismalatwo = ismalatwo;
        this.ismalathree = ismalathree;
        this.zarfone = zarfone;
        this.zarftwo = zarftwo;
        this.zarfthree = zarfthree;
        this.verbroot = verbroot;
    }

    public SarfSagheer() {
    }

    public String getWazanname() {
        return wazanname;
    }

    public void setWazanname(String wazanname) {
        this.wazanname = wazanname;
    }

    public String getVerbtype() {
        return verbtype;
    }

    public void setVerbtype(String verbtype) {
        this.verbtype = verbtype;
    }

    public String getMadhi() {
        return madhi;
    }

    public void setMadhi(String madhi) {
        this.madhi = madhi;
    }

    public String getMadhimajhool() {
        return madhimajhool;
    }

    public void setMadhimajhool(String madhimajhool) {
        this.madhimajhool = madhimajhool;
    }

    public String getMudharay() {
        return mudharay;
    }

    public void setMudharay(String mudharay) {
        this.mudharay = mudharay;
    }

    public String getMudharaymajhool() {
        return mudharaymajhool;
    }

    public void setMudharaymajhool(String mudharaymajhool) {
        this.mudharaymajhool = mudharaymajhool;
    }

    public String getIsmfael() {
        return ismfael;
    }

    public void setIsmfael(String ismfael) {
        this.ismfael = ismfael;
    }

    public String getIsmmafool() {
        return ismmafool;
    }

    public void setIsmmafool(String ismmafool) {
        this.ismmafool = ismmafool;
    }

    public String getWeakness() {
        return weakness;
    }

    public void setWeakness(String weakness) {
        this.weakness = weakness;
    }

    public String getWazan() {
        return wazan;
    }

    public void setWazan(String wazan) {
        this.wazan = wazan;
    }

    public String getAmrone() {
        return amrone;
    }

    public void setAmrone(String amrone) {
        this.amrone = amrone;
    }

    public String getAmrtwo() {
        return amrtwo;
    }

    public void setAmrtwo(String amrtwo) {
        this.amrtwo = amrtwo;
    }

    public String getAmrthree() {
        return amrthree;
    }

    public void setAmrthree(String amrthree) {
        this.amrthree = amrthree;
    }

    public String getNahiamrone() {
        return nahiamrone;
    }

    public void setNahiamrone(String nahiamrone) {
        this.nahiamrone = nahiamrone;
    }

    public String getNahiamrtwo() {
        return nahiamrtwo;
    }

    public void setNahiamrtwo(String nahiamrtwo) {
        this.nahiamrtwo = nahiamrtwo;
    }

    public String getNahiamrthree() {
        return nahiamrthree;
    }

    public void setNahiamrthree(String nahiamrthree) {
        this.nahiamrthree = nahiamrthree;
    }

    public String getIsmalaone() {
        return ismalaone;
    }

    public void setIsmalaone(String ismalaone) {
        this.ismalaone = ismalaone;
    }

    public String getIsmalatwo() {
        return ismalatwo;
    }

    public void setIsmalatwo(String ismalatwo) {
        this.ismalatwo = ismalatwo;
    }

    public String getIsmalathree() {
        return ismalathree;
    }

    public void setIsmalathree(String ismalathree) {
        this.ismalathree = ismalathree;
    }

    public String getZarfone() {
        return zarfone;
    }

    public void setZarfone(String zarfone) {
        this.zarfone = zarfone;
    }

    public String getZarftwo() {
        return zarftwo;
    }

    public void setZarftwo(String zarftwo) {
        this.zarftwo = zarftwo;
    }

    public String getZarfthree() {
        return zarfthree;
    }

    public void setZarfthree(String zarfthree) {
        this.zarfthree = zarfthree;
    }

    public String getVerbroot() {
        return verbroot;
    }

    public void setVerbroot(String verbroot) {
        this.verbroot = verbroot;
    }
}