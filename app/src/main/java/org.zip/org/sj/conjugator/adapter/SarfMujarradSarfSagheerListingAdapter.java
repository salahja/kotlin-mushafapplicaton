package org.sj.conjugator.adapter;

import static androidx.preference.PreferenceManager.getDefaultSharedPreferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.mushafconsolidated.R;
import com.google.android.gms.auth.api.signin.GoogleSignInOptionsExtension;
import com.google.android.material.textview.MaterialTextView;

import org.jetbrains.annotations.NotNull;
import org.sj.conjugator.fragments.SarfSagheer;
import org.sj.conjugator.interfaces.OnItemClickListener;

import java.util.ArrayList;

public class SarfMujarradSarfSagheerListingAdapter extends RecyclerView.Adapter<SarfMujarradSarfSagheerListingAdapter.ViewHolder> {
    private final Context context;
    private final ArrayList<String> madhi = new ArrayList<>();
    int rootcolor, weaknesscolor, wazancolor;
    int bookmarkpostion;
    OnItemClickListener mItemClickListener;
    //    private final Integer arabicTextColor;
    Context mycontext;
    String ismzaftitle = "(الْظَرْف:)";
    String ismalatitle = "( الآلَة:)";
    String alaheader = "اِسْم الآلَة";
    String zarfheader = "اِسْم الْظَرفْ";
    private ArrayList<SarfSagheer> sarfSagheer;
    private boolean mazeedregular;
    private int bookChapterno;
    private int bookVerseno;
    private Integer ayahNumber;
    private String urdu_font_selection;
    private int quran_arabic_font;
    private int urdu_font_size;
    private String arabic_font_selection;

    public SarfMujarradSarfSagheerListingAdapter(ArrayList<SarfSagheer> lists, Context context) {
        this.context = context;
        this.sarfSagheer = lists;

    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //      View view = LayoutInflater.from(parent.context!!).inflate(R.layout.sarfkabeercolumn, parent, false);
        View view = LayoutInflater.from(parent.context!!).inflate(R.layout.sarfsagheer, parent, false);
        //    View view = LayoutInflater.from(parent.context!!).inflate(R.layout.thulathisarfsagheer, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    public void onBindViewHolder(@NotNull ViewHolder holder, int position) {
        //  final List sarf = sarfSagheer.get(position);
//        final String[] array = (String[]) sarfSagheer.get(position).toArray();
//        SharedPreferences shared = getDefaultSharedPreferences(context);
//        String preferences = shared.getString("theme", "dark");
        SharedPreferences shared = getDefaultSharedPreferences(context);
        String preferences = shared.getString("theme", "dark");
       // SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.context!!);





        if (preferences.equals("dark") || preferences.equals("blue") ||preferences.equals("green")) {
            rootcolor = Color.CYAN;
            weaknesscolor = Color.YELLOW;
            wazancolor = Color.CYAN;

        } else {
            rootcolor = Color.RED;
            weaknesscolor = Color.BLACK;
            wazancolor = Color.RED;

        }
        String  zarf = new String ();
        String  ismala = new String ();
        String  amr = new String ();
        String  nahiamr = new String ();
        SarfSagheer sagheer = this.sarfSagheer.get(position);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);


        SharedPreferences sharedPreferences = android.preference.PreferenceManager.getDefaultSharedPreferences(context);
        String arabic_font_selection = sharedPreferences.getString("Arabic_Font_Selection", "me_quran.ttf");
        Typeface mequran = Typeface.createFromAsset(context.getAssets(),
                arabic_font_selection);



          if(sarfSagheer.get(0).getVerbtype().equals("mazeed")){
             holder.form.setVisibility(View.VISIBLE);
              holder.form.setText(sarfSagheer.get(0).getWazanname());
          }
          else{
              holder.form.setVisibility(View.GONE);
          }

        int length = sarfSagheer.size();
        Integer arabicFontsize = prefs.getInt("arabicFontSizeEntryArray", 20);
        holder.mamaroof.setText((CharSequence) sagheer.getMadhi());
        holder.mumaroof.setText((CharSequence) sagheer.getMudharay());
        holder.ismfail.setText((CharSequence) sagheer.getIsmfael());
        holder.mamajhool.setText((CharSequence) sagheer.getMadhimajhool());
        holder.mumajhool.setText((CharSequence) sagheer.getMudharaymajhool());
        holder.ismmafool.setText((CharSequence) sagheer.getIsmmafool());
        holder.amr.setText((CharSequence) sagheer.getAmrone());
        holder.nahiamr.setText((CharSequence) sagheer.getNahiamrone());
        holder.ismzarfheader.setText(zarfheader);
        holder.ismalaheader.setText(alaheader);
        zarf.append((CharSequence) sagheer.getIsmalaone()).append(", ").append(sagheer.getIsmalatwo()).append(", ").append(sagheer.getIsmalathree());
        ismala.append((CharSequence) sagheer.getZarfone()).append(", ").append(sagheer.getZarftwo()).append(", ").append(sagheer.getZarfthree());
        holder.ismzarf.setText(zarf);
        holder.ismala.setText(ismala);
        holder.weaknessname.setText((CharSequence) sagheer.getWeakness());
        holder.rootword.setText((CharSequence) sagheer.getVerbroot());
        holder.babname.setText((CharSequence) sagheer.getWazanname());
        holder.ismalaheader.setTextSize(arabicFontsize);
        holder.ismzarfheader.setTextSize(arabicFontsize);
        holder.mamaroof.setTextSize(arabicFontsize);
        holder.mumaroof.setTextSize(arabicFontsize);
        holder.masdaro.setTextSize(arabicFontsize);
        holder.masdart.setTextSize(arabicFontsize);
        holder.ismfail.setTextSize(arabicFontsize);
        holder.mamajhool.setTextSize(arabicFontsize);
        holder.mumajhool.setTextSize(arabicFontsize);
        holder.ismmafool.setTextSize(arabicFontsize);
        holder.amr.setTextSize(arabicFontsize);
        holder.nahiamr.setTextSize(arabicFontsize);
        holder.babname.setTextSize(arabicFontsize);
        holder.rootword.setTextSize(arabicFontsize);
        holder.ismzarf.setTextSize(arabicFontsize);
        holder.ismala.setTextSize(arabicFontsize);
        holder.weaknessname.setTextSize(arabicFontsize);
        holder.wazan.setTextSize(arabicFontsize);
        holder.mamaroof.setTypeface(mequran);
        holder.mumaroof.setTypeface(mequran);
        //   holder.masdaro.setTypeface(mequran);
        // holder.masdart.setTypeface(mequran);
        holder.ismfail.setTypeface(mequran);
        holder.mamajhool.setTypeface(mequran);
        holder.mumajhool.setTypeface(mequran);
        holder.ismmafool.setTypeface(mequran);
        holder.amr.setTypeface(mequran);
        holder.nahiamr.setTypeface(mequran);
        holder.babname.setTypeface(mequran);
        //  holder.babname.setTextColor(Color.YELLOW);
        holder.rootword.setTypeface(mequran);
        //  holder.rootword.setTextColor(Color.BLUE);
        holder.ismzarf.setTypeface(mequran);
        holder.ismala.setTypeface(mequran);
        holder.weaknessname.setTypeface(mequran);
        //  holder.weaknessname.setTextColor(Color.GREEN);
        holder.babname.setTextColor(wazancolor);
        holder.rootword.setTextColor(rootcolor);
        holder.weaknessname.setTextColor(weaknesscolor);
        //     holder.masdaro.setText((CharSequence) toArray.get(12));
        //     holder.masdart.setText((CharSequence) toArray.get(12));
        //     TextView textView = (TextView) findViewById(R.id.textView);
        //     Spannable spanDark = new SpannableString(textView.getText());
        //     span.setSpan(new RelativeSizeSpan(0.8f), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        //     textView.setText(span);
        //     ismfail,masdaro,mumaroof,mamaroof,ismmafool,masdart,mumajhool,mamajhool,ismzarf,ismala;
        //  holder.ismfail.setText(o.);
    }

    @Override
    public long getItemId(int position) {
        //  Surah surah = surahArrayList.get(position);
        return sarfSagheer.size();
    }

    public Object getItem(int position) {
        return sarfSagheer.get(position);
    }

    @Override
    public int getItemCount() {
        return sarfSagheer.size();

    }

    public void SetOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mItemClickListener = mItemClickListener;
    }

    public void setVerbArrayList(ArrayList<SarfSagheer> sarfsagheer) {
        this.sarfSagheer = sarfsagheer;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener // current clickListerner
    {
        public final MaterialTextView amr, nahiamr, ismfail, mumaroof,
                mamaroof, ismmafool, mumajhool, mamajhool,
                ismzarf, ismala;
        MaterialTextView form;
        public final TextView babno, ismalaheader, ismzarfheader, masdart, masdaro, babname, rootword, weaknessname, wazan;

        public ViewHolder(View view) {
            super(view);
            //    itemView.setTag(this);
            //     itemView.setOnClickListener(onItemClickListener);
            form=view.findViewById(R.id.form);
            babno = view.findViewById(R.id.babno);
            babno.setOnClickListener(this);
            form.setOnClickListener(this);
            form.setTag("form");
            ismfail = view.findViewById(R.id.ismfail);
            masdaro = view.findViewById(R.id.masdar);
            mumaroof = view.findViewById(R.id.mumaroof);
            mamaroof = view.findViewById(R.id.mamaroof);
            ismmafool = view.findViewById(R.id.ismmafool);
            masdart = view.findViewById(R.id.masdar2);
            mumajhool = view.findViewById(R.id.mumajhool);
            mamajhool = view.findViewById(R.id.mamajhool);
            amr = view.findViewById(R.id.amr);
            nahiamr = view.findViewById(R.id.nahiamr);
            ismala = view.findViewById(R.id.ismaalatable);
            ismzarf = view.findViewById(R.id.zarftable);
            babname = view.findViewById(R.id.babno);
            rootword = view.findViewById(R.id.rootword);
            weaknessname = view.findViewById(R.id.weknessname);
            ismzarfheader = view.findViewById(R.id.ismzarfheader);
            ismalaheader = view.findViewById(R.id.ismalaheader);
            wazan = view.findViewById(R.id.wazan);
       //     verify = view.findViewById(R.id.conjugateall);
            mumajhool.setTooltipText("Click for Verb Conjugation");
            view.setOnClickListener(this);
            ismfail.setOnClickListener(this);//R.id.ismfail);
            mumaroof.setOnClickListener(this);//R.id.mumaroof);
            mamaroof.setOnClickListener(this);//R.id.mamaroof);
            ismmafool.setOnClickListener(this);//R.id.ismmafool);
            mumajhool.setOnClickListener(this);//R.id.mumajhool);
            mamajhool.setOnClickListener(this);//R.id.mamajhool);
            amr.setOnClickListener(this);//R.id.amr);
            nahiamr.setOnClickListener(this);//R.id.nahiamr);
            ismala.setOnClickListener(this);//R.id.ismaalatable);
            ismzarf.setOnClickListener(this);//R.id.zarftable);
            rootword.setOnClickListener(this);//R.id.weaknesstype);
            babno.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
      //      verify.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getLayoutPosition());
            }
        }

    }

}
