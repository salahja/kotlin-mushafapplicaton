package org.sj.nounConjugation.trilateral.unaugmented.timeandplace;

import java.io.File;

/**
 * <p>Title: Sarf Program</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: ALEXO</p>
 *
 * @author Haytham Mohtasseb Billah
 * @version 1.0
 */
public class XmlTimeAndPlaceNounFormulaTreeCreator {
    private XmlTimeAndPlaceNounFormulaTreeCreator() {
    }

    public static XmlTimeAndPlaceNounFormulaTree buildNounFormulaTree(File xmlDiagramFile) throws Exception {
        //todo xml
    /*
        Digester digester = new Digester();
        digester.setValidating( false );

        digester.addObjectCreate("formulas", ElativeNounFormulaTree.class );

        digester.addObjectCreate("formulas/formula", ElativeNounFormula.class );
        digester.addSetProperties("formulas/formula", "c1","c1" );
        digester.addSetProperties("formulas/formula", "c2","c2" );
        digester.addSetProperties("formulas/formula", "c3", "c3" );

        digester.addSetNext( "formulas/formula" , "addFormula" );

        return (ElativeNounFormulaTree)digester.parse(xmlDiagramFile);
     */
        return null;

    }

}
