package sj.hisnul.activity;

/**
 * Created by sana on 26/7/18.
 */
public class ChildItem {
    private String name;
    private String ID;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
