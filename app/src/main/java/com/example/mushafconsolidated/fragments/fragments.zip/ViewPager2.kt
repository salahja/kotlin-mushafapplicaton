package com.example.mushafconsolidated.fragmentsimport

android.os.Bundleimport android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroupimport androidx.fragment.app.Fragmentimport androidx.viewpager2.widget.ViewPager2import com.example.mushafconsolidated.Entities.ChaptersAnaEntityimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.Utils
 
 

 
 
 
 





 

 

 

/**
 * A simple [Fragment] subclass.
 * Use the [ViewPager2.newInstance] factory method to
 * create an instance of this fragment.
 */
class ViewPager2 : Fragment {
    var viewPagertwo: ViewPager2? = null
    var util: Utils? = null
    var context: Context? = null

    // TODO: Rename and change types of parameters
    private var mParam1: String? = null
    private var mParam2: String? = null

    constructor(context: Context?) {
        this.context = context
    }

    constructor() {
        // Required empty public constructor
    }

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (getArguments() != null) {
            mParam1 =
                getArguments()!!.getString(com.example.mushafconsolidated.fragments.ViewPager2.Companion.ARG_PARAM1)
            mParam2 =
                getArguments()!!.getString(com.example.mushafconsolidated.fragments.ViewPager2.Companion.ARG_PARAM2)
        }
    }

    public override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        super.onCreate(savedInstanceState)
        val view: View = inflater.inflate(R.layout.fragment_view_pager2, container, false)
        viewPagertwo = view.findViewById(R.id.view_pagers)
        //
        util = Utils(context)
        val surahArrayList: ArrayList<ChaptersAnaEntity> = util!!.getAllAnaChapters()
        // viewPager2.setAdapter(new OrignalPager(this, list, viewPager2));
//  viewPager2.setAdapter(new ViewPagerAdapter(this, list, viewPager2));
        //   viewPagertwo.setAdapter(new ViewPagerAdapter((MainActivity) context, surahArrayList, viewPagertwo));
        return view
    }

    companion object {
        // TODO: Rename parameter arguments, choose names that match
        // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
        private val ARG_PARAM1: String = "param1"
        private val ARG_PARAM2: String = "param2"

        // TODO: Rename and change types and number of parameters
        fun newInstance(
            param1: String?,
            param2: String?
        ): com.example.mushafconsolidated.fragments.ViewPager2 {
            val fragment: com.example.mushafconsolidated.fragments.ViewPager2 =
                com.example.mushafconsolidated.fragments.ViewPager2()
            val args: Bundle = Bundle()
            args.putString(
                com.example.mushafconsolidated.fragments.ViewPager2.Companion.ARG_PARAM1,
                param1
            )
            args.putString(
                com.example.mushafconsolidated.fragments.ViewPager2.Companion.ARG_PARAM2,
                param2
            )
            fragment.setArguments(args)
            return fragment
        }
    }
}