package com.example.mushafconsolidated.fragmentsimport

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.Constant
import com.example.mushafconsolidated.Activity.QuranGrammarAct
import com.example.mushafconsolidated.Adapters.BookmarksShowAdapter
import com.example.mushafconsolidated.Entities.BookMarks
import com.example.mushafconsolidated.R
import com.example.mushafconsolidated.R.anim
import com.example.mushafconsolidated.R.layout
import com.example.mushafconsolidated.Utils
import com.example.mushafconsolidated.intrface.OnItemClickListener
import com.example.utility.SwipeToDeleteCallback
import com.google.android.material.snackbar.Snackbar

 
 
 
 
 
 
 
 
 




 

 

 

/**
 * Bookmark fragment class
 */
class BookmarkFragmentorig constructor() : Fragment(), AdapterView.OnItemClickListener {
    var coordinatorLayout: CoordinatorLayout? = null
    var layoutManager: RecyclerView.LayoutManager? = null
    private var bookmarksShowAdapter: BookmarksShowAdapter? = null
    private var mRecview: RecyclerView? = null
    public override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.fragment_bookmark, container, false)
        val utils: Utils = Utils(getActivity())
        val bookMarksNew: List<BookMarks> = Utils.Companion.getBookMarksNew()
        //  List<BookMarks> bookmarks = new DatabaseAccess().getBookmarks();
        bookmarksShowAdapter = BookmarksShowAdapter(getActivity())
        mRecview = view.findViewById(R.id.recyclerViewAdapterTranslation)
        coordinatorLayout = view.findViewById(R.id.coordinatorLayout)
        layoutManager = LinearLayoutManager(getActivity())
        mRecview.setLayoutManager(R.layoutManager)
        //    bookmarksShowAdapter.setBookMarkArrayList((ArrayList<String>) bookmarstringarray);
        bookmarksShowAdapter!!.setBookMarkArrayList(bookMarksNew)
        mRecview.setAdapter(bookmarksShowAdapter)
        //    mRecview.setLayoutManager(new LinearLayoutManager(getActivity()));
        enableSwipeToDeleteAndUndo()
        return view
    }

    private fun enableSwipeToDeleteAndUndo() {
        val swipeToDeleteCallback: SwipeToDeleteCallback =
            object : SwipeToDeleteCallback(getActivity()) {
                public override fun onSwiped(viewHolder: RecyclerView.ViewHolder, i: Int) {
                    //    final int position = viewHolder.getAdapterPosition();
                    //  final String item = mAdapter.getData().get(position);
                    //   mAdapter.removeItem(position);
                    val position: Int = viewHolder.getAdapterPosition()
                    val item: BookMarks =
                        bookmarksShowAdapter!!.getBookMarkArrayList().get(position)
                    //   final int code = item.hashCode();
                    bookmarksShowAdapter!!.getItemId(position)
                    bookmarksShowAdapter!!.removeItem(position)
                    val snackbar: Snackbar = Snackbar
                        .make(
                            (coordinatorLayout)!!,
                            "Item was removed from the list.",
                            Snackbar.LENGTH_LONG
                        )
                    snackbar.setAction("UNDO", object : View.OnClickListener {
                        public override fun onClick(view: View?) {
                            //     bookmarksShowAdapter.restoreItem(item, position);
                            mRecview!!.scrollToPosition(position)
                        }
                    })
                    snackbar.setActionTextColor(Color.CYAN)
                    snackbar.show()
                    val itemId: Long = bookmarksShowAdapter!!.getItemId(position)
                    val bookmarkid: Int = bookmarksShowAdapter!!.getBookmarid()
                    //     bookmarksShowAdapter.getBookChapterno();
                    //      bookmarksShowAdapter.getBookMarkArrayList(bookmarkid)
                    //  Utils butils = new Utils(getActivity());
                    //  butils.deleteBookmarks(bookmarid);
                    Utils.Companion.deleteBookMarks(item)
                }
            }
        val itemTouchhelper: ItemTouchHelper = ItemTouchHelper(swipeToDeleteCallback)
        itemTouchhelper.attachToRecyclerView(mRecview)
    }

    public override fun onResume() {
        super.onResume()
    }

    public override fun onItemClick(parent: AdapterView<*>?, view: View, position: Int, id: Long) {}
    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bookmarksShowAdapter!!.SetOnItemClickListener(object : OnItemClickListener {
            public override fun onItemClick(v: View?, position: Int) {
                val bmark: BookMarks = bookmarksShowAdapter!!.getItem(position) as BookMarks
                //        ChaptersAnaEntity surah = (ChaptersAnaEntity) bookmarksShowAdapter.getItem(position);
                val dataBundle: Bundle = Bundle()
                dataBundle.putInt(Constant.SURAH_ID, bmark.getChapterno().toInt())
                dataBundle.putInt(Constant.AYAHNUMBER, bmark.getVerseno().toInt())
                dataBundle.putString(Constant.SURAH_ARABIC_NAME, bmark.getSurahname())
                //                dataBundle.putInt(VERSESCOUNT,bmark.getVersescount());
                //VersesFragment frag = new VersesFragment();
                //   frag.setArguments(dataBundle);
                val header: String = bmark.getHeader()
                var fragment: Fragment?
                val readingintent: Intent = Intent(getActivity(), QuranGrammarAct::class.java)
                readingintent.putExtra(Constant.MUFRADATFRAGTAG, false)
                readingintent.putExtra(Constant.CHAPTER, bmark.getChapterno().toInt())
                readingintent.putExtra(Constant.AYAH_ID, bmark.getVerseno().toInt())
                readingintent.putExtra(Constant.CHAPTERORPART, true)
                readingintent.putExtra(Constant.SURAH_ARABIC_NAME, bmark.getSurahname())
                readingintent.putExtra(Constant.WBW, true)
                startActivity(readingintent)
            }
        })
    }

    private fun loadFragments(fragment: Fragment, fragtag: String) {
        // load fragment
        val transaction: FragmentTransaction =
            getActivity()!!.getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(anim.left_slide, android.R.anim.fade_out)
        transaction.replace(R.id.frame_container, fragment)
        transaction.addToBackStack(fragtag)
        transaction.commit()
    }
}