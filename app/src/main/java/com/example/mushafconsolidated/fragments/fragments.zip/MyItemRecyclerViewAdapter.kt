package com.example.mushafconsolidated.fragmentsimport

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mushafconsolidated.databinding.FragmentDuaItemBinding
import database.entity.DuaDetails


/**
 * [RecyclerView.Adapter] that can display a [PlaceholderItem].
 * TODO: Replace the implementation with code for your data type.
 */
class MyItemRecyclerViewAdapter constructor(items: ArrayList<DuaDetails>) :
    RecyclerView.Adapter<MyItemRecyclerViewAdapter.ViewHolder>() {
    private val mValues: List<DuaDetails>

    init {
        mValues = items
    }

    public override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyItemRecyclerViewAdapter.ViewHolder {
        return MyItemRecyclerViewAdapter.ViewHolder(
            FragmentDuaItemBinding.inflate(
                LayoutInflater.from(
                    parent.getContext()
                ), parent, false
            )
        )
    }

    public override fun onBindViewHolder(
        holder: MyItemRecyclerViewAdapter.ViewHolder,
        position: Int
    ) {
        val mItem: DuaDetails = mValues.get(position)
        holder.mIdView.setText(mItem.get_id().toString())
        holder.mContentView.setText(mItem.getAr_dua())
    }

    public override fun getItemCount(): Int {
        return mValues.size
    }

    inner class ViewHolder constructor(binding: FragmentDuaItemBinding) :
        RecyclerView.ViewHolder(binding.getRoot()) {
        val mIdView: TextView
        val mContentView: TextView
        var mItem: DuaDetails? = null

        init {
            mIdView = binding.itemNumber
            mContentView = binding.content
        }

        public override fun toString(): String {
            return super.toString() + " '" + mContentView.getText() + "'"
        }
    }
}