package com.example.mushafconsolidated.fragmentsimport

import BookMarks
import BookMarksPojo
import android.app.AlertDialog
import android.app.Dialog

import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mushafconsolidated.R
import com.example.mushafconsolidated.intrfaceimport.OnItemClickListener
import com.example.mushafconsolidatedimport.Utils
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import sj.hisnul.adapter.BookmarCrateAdapter










 





/**
 *
 * A fragment that shows a list of items as a modal bottom sheet.
 *
 * You can show this modal bottom sheet from your activity like this:
 * <pre>
 * ThemeListPrefrence.newInstance(30).show(getSupportFragmentManager(), "dialog");
</pre> *
 */
class BookMarkCreateFrag constructor() : BottomSheetDialogFragment(), OnItemClickListener,
    View.OnClickListener {
    private var recyclerView: RecyclerView? = null
    private var suraname: String? = null
    private var chapter: Int = 0
    private var verse: Int = 0
    private var selectedposition: Int = 0
    var addtocollection: MaterialButton? = null
    var newcollection: MaterialButton? = null
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    var mItemClickListener: OnItemClickListener? = null
    var radioGroup: RadioGroup? = null
    private val bookmarCrateAdapter: BookmarCrateAdapter? = null
    var frameLayout: RelativeLayout? = null
    var collectionC: List<BookMarksPojo> = ArrayList()
    var bookMarks: ArrayList<BookMarks> = ArrayList()
    fun SetOnItemClickListener(mItemClickListener: OnItemClickListener?) {
        this.mItemClickListener = mItemClickListener
    }

    public override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val bundle: Bundle? = getArguments()
        assert(bundle != null)
        val stringArray: Array<String>? =
            bundle!!.getStringArray(BookMarkCreateFrag.Companion.ARG_OPTIONS_DATA)
        chapter = stringArray!!.get(0).toInt()
        verse = stringArray.get(1).toInt()
        suraname = (stringArray.get(2))
        return inflater.inflate(R.layout.bookmark_create, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        recyclerView = view.findViewById(R.id.recycler_view)
        recyclerView.setLayoutManager(LinearLayoutManager(context!!))
        val details: ArrayList<String> = ArrayList()
        val utils: Utils = Utils(getActivity())
        collectionC = utils.collectionC
        val bookmarCrateAdapter: BookmarCrateAdapter = BookmarCrateAdapter(collectionC)
        newcollection = view.findViewById(R.id.newcollection)
        addtocollection = view.findViewById(R.id.addtocollection)
        newcollection.setOnClickListener(this)
        addtocollection.setOnClickListener(this)
        newcollection.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                val dialogPicker: AlertDialog.  = AlertDialog. (
                    requireActivity()
                )
                val dlg: Dialog = Dialog(requireActivity())
                //  AlertDialog dialog =  .create();
                //      soraList = utils.getAllAnaChapters();
                val inflater: LayoutInflater = requireActivity().getLayoutInflater()
                val view: View = inflater.inflate(R.layout.folder_bookmark, null)
                //  View view = inflater.inflate(R.layout.activity_wheel, null);
                dialogPicker.setView(view)
                val mTextView: EditText = view.findViewById(R.id.tvFolderName)
                dialogPicker.setPositiveButton(
                    "Done",
                    DialogInterface.OnClickListener({ dialogInterface: DialogInterface?, i: Int ->
                        val str: String = mTextView.getText().toString()
                        bookMarkSelected(v, selectedposition, str)
                    })
                )
                dialogPicker.setNegativeButton(
                    "Cancel",
                    DialogInterface.OnClickListener({ dialogInterface: DialogInterface?, i: Int -> })
                )
                dialogPicker.show()
            }
        })
        addtocollection.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                val bookMarksPojo: BookMarksPojo = collectionC.get(selectedposition)
                bookMarkSelected(
                    v,
                    bookMarksPojo.getChapterno().toInt(),
                    bookMarksPojo.getHeader().toString()
                )
            }
        })
        recyclerView.setAdapter(bookmarCrateAdapter)
        bookmarCrateAdapter.SetOnItemClickListener(object :
            BookmarCrateAdapter.OnItemClickListener {
            public override fun onItemClick(v: View, position: Int) {
                val holder: RecyclerView.ViewHolder? =
                    recyclerView.findViewHolderForAdapterPosition(position)
                if (holder != null) {
                    val ck: CheckBox? = holder.itemView.findViewById(R.id.checkbox)
                    if (ck != null) {
                        selectedposition = position
                    }
                    println("check")
                }
                val tag: Any = v.getTag()
                if ((tag == "newcollection")) {
                    val dialogPicker: AlertDialog.  = AlertDialog. (
                        (getActivity())!!
                    )
                    val dlg: Dialog = Dialog((getActivity())!!)
                    //  AlertDialog dialog =  .create();
                    //      soraList = utils.getAllAnaChapters();
                    val inflater: LayoutInflater = getActivity()!!.getLayoutInflater()
                    val view: View = inflater.inflate(R.layout.folder_bookmark, null)
                    //  View view = inflater.inflate(R.layout.activity_wheel, null);
                    dialogPicker.setView(view)
                    val mTextView: EditText = view.findViewById(R.id.tvFolderName)
                    dialogPicker.setPositiveButton(
                        "Done",
                        DialogInterface.OnClickListener({ dialogInterface: DialogInterface?, i: Int ->
                            val str: String = mTextView.getText().toString()
                            bookMarkSelected(v, position, str)
                        })
                    )
                    dialogPicker.setNegativeButton(
                        "Cancel",
                        DialogInterface.OnClickListener({ dialogInterface: DialogInterface?, i: Int -> })
                    )
                    dialogPicker.show()
                } else if ((tag == "addcollection")) {
                    --selectedposition
                    val book: BookMarksPojo = collectionC.get(selectedposition)
                    if (holder != null) {
                        val ck: CheckBox =
                            recyclerView.findViewHolderForAdapterPosition(position - 2)!!.itemView.findViewById(
                                R.id.checkbox
                            )
                        println("check")
                    }
                    bookMarkSelected(v, selectedposition, book.getHeader())
                    Toast.makeText(getActivity(), "create collections", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun bookMarkSelected(view: View, position: Int, text: String) {
        //  position = flowAyahWordAdapter.getAdapterposition();
        val en: BookMarks = BookMarks()
        en.setHeader(text)
        en.setChapterno(chapter.toString())
        en.setVerseno(verse.toString())
        en.setSurahname((suraname)!!)
        //     Utils utils = new Utils(ReadingSurahPartActivity.this);
        val utils: Utils = Utils(context!!)
        utils.insertBookMark(en)
        //     View view = findViewById(R.id.bookmark);
        val snackbar: Snackbar = Snackbar
            .make(view, "BookMark Created", Snackbar.LENGTH_LONG)
        snackbar.setActionTextColor(Color.BLUE)
        snackbar.setTextColor(Color.CYAN)
        snackbar.setBackgroundTint(Color.BLACK)
        snackbar.show()
    }

    public override fun onItemClick(v: View?, position: Int) {}
    public override fun onClick(v: View) {}

    companion object {
        val TAG: String = "opton"

        // TODO: Customize parameter argument names
        private val ARG_OPTIONS_DATA: String = "item_count"

        // TODO: Customize parameters
        fun newInstance(data: Array<String>): BookMarkCreateFrag {
            val fragment: BookMarkCreateFrag = BookMarkCreateFrag()
            val args: Bundle = Bundle()
            args.putStringArray(BookMarkCreateFrag.Companion.ARG_OPTIONS_DATA, data)
            fragment.setArguments(args)
            return fragment
        }
    }
}