package com.example.mushafconsolidated.fragments.placeholderimport


/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 *
 *
 * TODO: Replace all uses of this class before publishing your app.
 */
object PlaceholderContent {
    /**
     * An array of sample (placeholder) items.
     */
    val ITEMS: List<PlaceholderContent.PlaceholderItem> = ArrayList()

    /**
     * A map of sample (placeholder) items, by ID.
     */
    val ITEM_MAP: Map<String, PlaceholderContent.PlaceholderItem> = HashMap()
    private val COUNT: Int = 25

    init {
        // Add some sample items.
        for (i in 1..PlaceholderContent.COUNT) {
            PlaceholderContent.addItem(PlaceholderContent.createPlaceholderItem(i))
        }
    }

    private fun addItem(item: PlaceholderContent.PlaceholderItem) {
        PlaceholderContent.ITEMS.add(item)
        PlaceholderContent.ITEM_MAP.put(item.id, item)
    }

    private fun createPlaceholderItem(position: Int): PlaceholderContent.PlaceholderItem {
        return PlaceholderContent.PlaceholderItem(
            position.toString(),
            "Item " + position,
            PlaceholderContent.makeDetails(position)
        )
    }

    private fun makeDetails(position: Int): String {
        val  : String  = String ()
         .append("Details about Item: ").append(position)
        for (i in 0 until position) {
             .append("\nMore details information here.")
        }
        return  .toString()
    }

    /**
     * A placeholder item representing a piece of content.
     */
    class PlaceholderItem constructor(val id: String, val content: String, val details: String) {
        public override fun toString(): String {
            return content
        }
    }
}