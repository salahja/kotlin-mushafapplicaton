package com.example.mushafconsolidated.fragmentsimport

import QuranEntity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.RadioGroup
import android.widget.RelativeLayout
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

android.os.Bundleimport android.text.Htmlimport android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroupimport android.widget.RadioButtonimport android.widget.RadioGroupimport android.widget.RelativeLayoutimport android.widget.TextViewimport androidx.preference.PreferenceManagerimport androidx.recyclerview.widget.LinearLayoutManagerimport androidx.recyclerview.widget.RecyclerViewimport com.example.Constantimport com.example.mushafconsolidated.Entities.QuranEntityimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.Utilsimport com.example.mushafconsolidated.fragments.SelectedWordAyahimport com.example.mushafconsolidated.intrface.OnItemClickListenerimport com.example.mushafconsolidated.receivers.AudioAppConstantsimport com.google.android.material.bottomsheet.BottomSheetDialogFragment
 
 
 
 
 
 

 
 
  
 
 
 
 
 
 

/**
 *
 * A fragment that shows a list of items as a modal bottom sheet.
 *
 * You can show this modal bottom sheet from your activity like this:
 * <pre>
 * ThemeListPrefrence.newInstance(30).show(getSupportFragmentManager(), "dialog");
</pre> *
 */
class SelectedWordAyah constructor() : BottomSheetDialogFragment() {
    private var quranEntities: List<QuranEntity>? = null
    private var ayah: Int = 0
    private var surah: Int = 0
    private var surahname: String? = null
    private var arabicword: String? = null
    private var wordmeaning: String? = null
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    var mItemClickListener: OnItemClickListener? = null
    var radioGroup: RadioGroup? = null
    private var fontQuranAdapter: SelectedWordAyah.FontQuranAdapter? = null
    var frameLayout: RelativeLayout
    fun SetOnItemClickListener(mItemClickListener: OnItemClickListener?) {
        this.mItemClickListener = mItemClickListener
    }

    public override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val bundle: Bundle? = getArguments()
        val stringArray: Array<String>? =
            bundle!!.getStringArray(SelectedWordAyah.Companion.ARG_OPTIONS_DATA)
        surah = stringArray!!.get(0).toInt()
        ayah = stringArray.get(1).toInt()
        surahname = stringArray.get(2)
        arabicword = stringArray.get(3)
        wordmeaning = stringArray.get(4)
        val utils: Utils = Utils(getActivity())
        quranEntities = Utils.Companion.getsurahayahVerses(surah, ayah)
        return inflater.inflate(R.layout.quran_list_dialog, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val recyclerView: RecyclerView = view.findViewById(R.id.recycler_view)
        recyclerView.setLayoutManager(LinearLayoutManager(context!!))
        val details: ArrayList<String> = ArrayList()
        fontQuranAdapter = SelectedWordAyah.FontQuranAdapter(quranEntities)
        recyclerView.setAdapter(fontQuranAdapter)
        fontQuranAdapter!!.SetOnItemClickListener(object : OnItemClickListener {
            public override fun onItemClick(v: View?, position: Int) {
                val checkedRadioButtonId: Int = radioGroup!!.getCheckedRadioButtonId()
            }
        })
    }

    private inner class ViewHolder internal constructor(
        inflater: LayoutInflater,
        parent: ViewGroup?
    ) : RecyclerView.ViewHolder(
        inflater.inflate(
            layout.selectwordverse, parent, false
        )
    ), View.OnClickListener {
        var purple: RadioButton? = null
        var black: RadioButton? = null
        var dark_blue: RadioButton? = null
        var green: RadioButton? = null
        var brown: RadioButton? = null
        var verse: TextView
        var translation: TextView
        var tafsir: TextView
        var wordDetails: TextView? = null
        var surah: TextView
        var ayadetail: TextView
        var arabicword: TextView
        var meaning: TextView

        init {
            // TODO: Customize the item layout
            //  super(inflater.inflate(R.layout.fragment_item_list_dialog_list_dialog_item, parent, false));
            verse = itemView.findViewById(R.id.verse)
            translation = itemView.findViewById(R.id.translation)
            frameLayout = itemView.findViewById(R.id.bottomSheet)
            tafsir = itemView.findViewById(R.id.tafsir)
            surah = itemView.findViewById(R.id.surah)
            ayadetail = itemView.findViewById(R.id.ayadetail)
            arabicword = itemView.findViewById(R.id.arabicword)
            meaning = itemView.findViewById(R.id.meaning)
            itemView.setOnClickListener(this)
        }

        public override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener!!.onItemClick(v, getLayoutPosition())
            }
        }
    }

    private inner class FontQuranAdapter constructor(var quranEntities: List<QuranEntity>) :
        RecyclerView.Adapter<SelectedWordAyah.ViewHolder>() {
        private var mItemClickListener: OnItemClickListener? = null
        public override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): SelectedWordAyah.ViewHolder {
            return SelectedWordAyah.ViewHolder(R.layoutInflater.from(parent.context!!), parent)
        }

        public override fun onBindViewHolder(holder: SelectedWordAyah.ViewHolder, position: Int) {
            val sharedPreferences: SharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(
                    (context!!)!!
                )
            val theme: String? = PreferenceManager.getDefaultSharedPreferences(
                (getActivity())!!
            ).getString("themepref", "dark")
            val entity: QuranEntity = quranEntities.get(position)
            holder.verse.setText(entity.getQurantext())
            holder.translation.setText(Html.fromHtml(entity.getTranslation()))
            holder.tafsir.setText(entity.getTafsir_kathir())
            holder.surah.setText(surahname)
            holder.arabicword.setText(arabicword)
            holder.meaning.setText(wordmeaning)
            // String word="";
            val word: String  = String ()
            word.append(surah).append(":").append(ayah)
            //    word.append(String.valueOf(surah)).append(":").append(String.valueOf(ayah)).append(" ").append(arabicword).append(" ").append(wordmeaning).append( "").append("(").append(surahname).append(")");
            holder.ayadetail.setText(word)
        }

        public override fun getItemCount(): Int {
            return 1
        }

        fun SetOnItemClickListener(mItemClickListener: OnItemClickListener?) {
            this.mItemClickListener = mItemClickListener
        }
    }

    companion object {
        val TAG: String = "opton"

        // TODO: Customize parameter argument names
        private val ARG_OPTIONS_DATA: String = "item_count"

        // TODO: Customize parameters
        fun newInstance(data: Array<String?>?): SelectedWordAyah {
            val fragment: SelectedWordAyah = SelectedWordAyah()
            val args: Bundle = Bundle()
            args.putStringArray(SelectedWordAyah.Companion.ARG_OPTIONS_DATA, data)
            fragment.setArguments(args)
            val bundle: Bundle? = fragment.getArguments()
            if (null != bundle) {
                bundle.getInt(Constant.SURAH_ID)
                bundle.getInt(AudioAppConstants.General.Companion.AYA_ID)
            }
            return fragment
        }
    }
}