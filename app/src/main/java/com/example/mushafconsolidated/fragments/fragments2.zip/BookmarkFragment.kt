package com.example.mushafconsolidated.fragmentsimport

android.graphics.Colorimport android.os.Bundleimport android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroupimport android.widget.ListViewimport android.widget.TextViewimport androidx.coordinatorlayout.widget.CoordinatorLayoutimport androidx.fragment.app.Fragmentimport androidx.fragment.app.FragmentManagerimport androidx.lifecycle.Lifecycleimport androidx.recyclerview.widget.ItemTouchHelperimport androidx.recyclerview.widget.LinearLayoutManagerimport androidx.recyclerview.widget.RecyclerViewimport androidx.viewpager2.adapter.FragmentStateAdapterimport androidx.viewpager2.widget.ViewPager2import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallbackimport com.example.Constantimport com.example.mushafconsolidated.Activity.QuranGrammarActimport com.example.mushafconsolidated.Adapters.BookmarksShowAdapterimport com.example.mushafconsolidated.Entities.BookMarksimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.R.stringimport com.example.mushafconsolidated.Utilsimport com.example.mushafconsolidated.fragments.BookmarkFragmentimport com.example.mushafconsolidated.fragments.CollectionFragimport com.example.mushafconsolidated.fragments.PinsFragmentimport com.example.mushafconsolidated.intrface.OnItemClickListenerimport com.example.utility.SwipeToDeleteCallbackimport com.google.android.material.snackbar.Snackbarimport com.google.android.material.tabs.TabLayoutimport com.google.android.material.tabs.TabLayout.OnTabSelectedListenerimport com.google.android.material.tabs.TabLayoutMediatorimport com.google.android.material.tabs.TabLayoutMediator.TabConfigurationStrategyimport okhttp3.Request. .get

 

 

 






 

 

 

/**
 * Bookmark fragment class
 */
class BookmarkFragment constructor() : Fragment() {
    var coordinatorLayout: CoordinatorLayout? = null
    var layoutManager: RecyclerView.LayoutManager? = null
    private var bookmarksShowAdapter: BookmarksShowAdapter? = null
    private val mRecview: RecyclerView? = null
    private var mViewPager: ViewPager2? = null
    private val listView: ListView? = null
    var mediator: TabLayoutMediator? = null
    public override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.bookmark_frag_tablayout, container, false)
        val utils: Utils = Utils(getActivity())
        val tabLayout: TabLayout = view.findViewById(R.id.tabs)
        val lifecycle: Lifecycle = getViewLifecycleOwner().lifecycle
        val fm: FragmentManager = getActivity()!!.getSupportFragmentManager()
        val mSectionsPagerAdapter: BookmarkFragment.ViewStateAdapter =
            BookmarkFragment.ViewStateAdapter(fm, lifecycle)


        //  mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        mViewPager = view.findViewById(R.id.container)
        mViewPager.setAdapter(mSectionsPagerAdapter)
        mediator = TabLayoutMediator(
            tabLayout,
            mViewPager,
            TabConfigurationStrategy({ tab: TabLayout.Tab, position: Int ->
                tab.setText(BookmarkFragment.Companion.TAB_TITLES.get(position))
            })
        )
        mediator!!.attach()
        //    new TabLayoutMediator(tabLayout, mViewPager, (tab, position) -> tab.setText(TAB_TITLES[position])).attach();

        //clickable application title
        val applicationTitle: TextView = view.findViewById<View>(R.id.title) as TextView
        applicationTitle.setText(getString(string.bookmarkst))
        val listener: OnItemClickListener? = null

        //  List<BookMarks> bookmarks = new DatabaseAccess().getBookmarks();
        bookmarksShowAdapter = BookmarksShowAdapter(getActivity())
        layoutManager = LinearLayoutManager(getActivity())
        tabLayout.addOnTabSelectedListener(object : OnTabSelectedListener {
            public override fun onTabSelected(tab: TabLayout.Tab) {
                mViewPager.setCurrentItem(tab.getPosition())
            }

            public override fun onTabUnselected(tab: TabLayout.Tab?) {}
            public override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
        mViewPager.registerOnPageChangeCallback(object : OnPageChangeCallback() {
            public override fun onPageSelected(position: Int) {
                tabLayout.selectTab(tabLayout.getTabAt(position))
            }
        })
        return view
    }

    private fun enableSwipeToDeleteAndUndo() {
        val swipeToDeleteCallback: SwipeToDeleteCallback =
            object : SwipeToDeleteCallback(getActivity()) {
                public override fun onSwiped(viewHolder: RecyclerView.ViewHolder, i: Int) {
                    val position: Int = viewHolder.getAdapterPosition()
                    val item: BookMarks =
                        bookmarksShowAdapter!!.getBookMarkArrayList().get(position)
                    //   final int code = item.hashCode();
                    bookmarksShowAdapter!!.getItemId(position)
                    bookmarksShowAdapter!!.removeItem(position)
                    val snackbar: Snackbar = Snackbar
                        .make(
                            (coordinatorLayout)!!,
                            "Item was removed from the list.",
                            Snackbar.LENGTH_LONG
                        )
                    snackbar.setAction("UNDO", object : View.OnClickListener {
                        public override fun onClick(view: View?) {
                            //     bookmarksShowAdapter.restoreItem(item, position);
                            mRecview!!.scrollToPosition(position)
                        }
                    })
                    snackbar.setActionTextColor(Color.CYAN)
                    snackbar.show()
                    val itemId: Long = bookmarksShowAdapter!!.getItemId(position)
                    val bookmarkid: Int = bookmarksShowAdapter!!.getBookmarid()
                    bookmarksShowAdapter!!.getBookChapterno()
                    //      bookmarksShowAdapter.getBookMarkArrayList(bookmarkid)
                    Utils.Companion.deleteBookMarks(item)
                }
            }
        val itemTouchhelper: ItemTouchHelper = ItemTouchHelper(swipeToDeleteCallback)
        itemTouchhelper.attachToRecyclerView(mRecview)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bookmarksShowAdapter!!.SetOnItemClickListener(object : OnItemClickListener {
            public override fun onItemClick(v: View?, position: Int) {
                val bmark: BookMarks = bookmarksShowAdapter!!.getItem(position) as BookMarks
                //        ChaptersAnaEntity surah = (ChaptersAnaEntity) bookmarksShowAdapter.getItem(position);
                val dataBundle: Bundle = Bundle()
                dataBundle.putInt(Constant.SURAH_ID, bmark.getChapterno().toInt())
                dataBundle.putInt(Constant.AYAHNUMBER, bmark.getVerseno().toInt())
                dataBundle.putString(Constant.SURAH_ARABIC_NAME, bmark.getSurahname())
                val header: String = bmark.getHeader()
                var fragment: Fragment?
                val readingintent: Intent = Intent(getActivity(), QuranGrammarAct::class.java)
                readingintent.putExtra(Constant.MUFRADATFRAGTAG, false)
                readingintent.putExtra(Constant.CHAPTER, bmark.getChapterno().toInt())
                readingintent.putExtra(Constant.AYAH_ID, bmark.getVerseno().toInt())
                readingintent.putExtra(Constant.CHAPTERORPART, true)
                readingintent.putExtra(Constant.SURAH_ARABIC_NAME, bmark.getSurahname())
                readingintent.putExtra(Constant.WBW, true)
                startActivity(readingintent)
            }
        })
    }

    private class ViewStateAdapter constructor(
        fragmentManager: FragmentManager,
        lifecycle: Lifecycle
    ) : FragmentStateAdapter(fragmentManager, lifecycle) {
        public override fun createFragment(position: Int): Fragment {
            when (position) {
                0 -> return PinsFragment()
                1 -> return CollectionFrag()
                else -> return PinsFragment()
            }
        }

        public override fun getItemCount(): Int {
            return 2
        }
    }

    public override fun onDestroyView() {
        super.onDestroyView()
        mediator!!.detach()
        mediator = null
    }

    companion object {
        private val TAB_TITLES: IntArray = intArrayOf(string.pins, string.collection)
    }
}