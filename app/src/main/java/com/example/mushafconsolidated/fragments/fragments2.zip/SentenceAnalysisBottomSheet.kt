package com.example.mushafconsolidated.fragmentsimport

import NewCorpusExpandWbwPOJO
import VerbWazan
import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.preference.PreferenceManager
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.Constant
import com.example.mushafconsolidated.Activity.LughatWordDetailsAct
import com.example.mushafconsolidated.Activity.WordOccuranceAct
import com.example.mushafconsolidated.Adapters.RootWordDisplayAdapter
import com.example.mushafconsolidated.Adapters.SentenceRootWordDisplayAdapter
import com.example.mushafconsolidated.Entities.NewCorpusExpandWbwPOJO
import com.example.mushafconsolidated.Entities.NewKanaEntity
import com.example.mushafconsolidated.Entities.NewMudhafEntity
import com.example.mushafconsolidated.Entities.NewNasbEntity
import com.example.mushafconsolidated.Entities.NewShartEntity
import com.example.mushafconsolidated.Entities.NounCorpus
import com.example.mushafconsolidated.Entities.SifaEntity
import com.example.mushafconsolidated.Entities.VerbCorpus
import com.example.mushafconsolidated.Entities.VerbWazan
import com.example.mushafconsolidated.R
import com.example.mushafconsolidated.R.anim
import com.example.mushafconsolidated.R.layout
import com.example.mushafconsolidated.Utils
import com.example.mushafconsolidated.intrface.OnItemClickListener
import com.example.mushafconsolidated.model.SarfSagheerPOJO
import com.example.mushafconsolidated.modelimport.SarfSagheerPOJO
import com.example.utility.CorpusUtilityorig
import com.example.utility.QuranGrammarApplication
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import database.DatabaseUtils
import database.entity.MujarradVerbs
import org.sj.conjugator.activity.ConjugatorTabsActivity
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


/**
 *
 * A fragment that shows a list of items as a modal bottom sheet.
 *
 * You can show this modal bottom sheet from your activity like this:
 * <pre>
 * ItemListDialogFragment.newInstance(30).show(getSupportFragmentManager(), "dialog");
</pre> *
 */
class SentenceAnalysisBottomSheet constructor() : BottomSheetDialogFragment() {
    var chapterid: Int = 0
    var ayanumber: Int = 0
    var isMazeedSarfSagheer: Boolean = false
    var isThulathiSarfSagheer: Boolean = false
    var isIsverbconjugaton: Boolean = false
    var isParticiples: Boolean = false
    var isNoun: Boolean = false
    var wordetailsall: HashMap<Int, HashMap<String, SpannableString?>> = HashMap()
    var verbdetailsall: HashMap<Int, HashMap<String, String>?> = HashMap()
    var vbdetail: HashMap<String, String> = HashMap()
    var wordbdetail: HashMap<String, SpannableString >? = null
    var issentence: Boolean = false
    var ThulathiMazeedConjugatonList: ArrayList<ArrayList<*>>? = null
    var sarf: SarfSagheerPOJO? = null
    private var preferences: String? = null
    private var prefs: SharedPreferences? = null
    var harfNasbAndZarf: String? = null
    private val spannableShart: SpannableString ? = null
    private val spannableHarf: SpannableString ? = null
    private val spannablemousufmudhaf: SpannableString ? = null
    private var spannable: SpannableString ? = null
    private val SencorpusSurahWord: ArrayList<NewCorpusExpandWbwPOJO>? = null
    private var corpusSurahWord: ArrayList<NewCorpusExpandWbwPOJO>? = null
    private var dialog: AlertDialog? = null
    private var themepreference: String? = null
    private var finalverbdetail: HashMap<Int, HashMap<String, String>?>? = null
    private val ismfaelmafool: ArrayList<ArrayList<*>>? = null
    private var vb: VerbWazan? = null
    private val rwAdapter: RootWordDisplayAdapter? = null
    private var sentenceRootWordDisplayAdapter: SentenceRootWordDisplayAdapter? = null
    fun setIsverbconjugaton(isverbconjugaton: Boolean) {
        isIsverbconjugaton = isverbconjugaton
    }

    public override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return super.onCreateDialog(savedInstanceState)
    }

    public override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.sentence_root_dialog_fragment, container, false)
        val recyclerView: RecyclerView = view.findViewById(R.id.recview)
        val bundle: Bundle? = getArguments()
        val stringArray: Array<String>? =
            bundle!!.getStringArray(SentenceAnalysisBottomSheet.Companion.ARG_OPTIONS_DATA)
        chapterid = stringArray!!.get(0).toInt()
        prefs = PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.context!!)
        preferences = prefs.getString("theme", "dark")
        val  : AlertDialog.  = AlertDialog. (
            (getActivity())!!
        )
         .setCancelable(false) // if you want user to wait for some process to finish,
         .setView(R.layout.layout_loading_dialog)
        dialog =  .create()
        themepreference = prefs.getString("theme", "dark")
        //  recyclerView.setLayoutParams(new CoordinatorLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        sentenceRootWordDisplayAdapter = SentenceRootWordDisplayAdapter(context!!)
        val shared: SharedPreferences =
            androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                (context!!)!!
            )
        issentence = shared.getBoolean("grammarsentence", false)
        ayanumber = stringArray.get(1).toInt()
        val wbwtranslation: String = stringArray.get(2)
        val wordno: Int = stringArray.get(3).toInt()
        val utils: Utils = Utils(getActivity())
        val ex: ExecutorService = Executors.newSingleThreadExecutor()
        ex.execute(Runnable({
            getActivity()!!.runOnUiThread(Runnable({ dialog!!.show() }))
            //  setAyanSpans();
            NewsetAyanSpans()
            getActivity()!!.runOnUiThread(Runnable({
                dialog!!.dismiss()
                finalverbdetail = HashMap()
                // Copy all data from hashMap into TreeMap
                finalverbdetail!!.putAll(verbdetailsall)
                sentenceRootWordDisplayAdapter!!.setRootWordsAndMeanings(
                    corpusSurahWord,
                    spannableShart,
                    spannableHarf,
                    spannable,
                    wordetailsall,
                    finalverbdetail,
                    getActivity()
                )
                recyclerView.setAdapter(sentenceRootWordDisplayAdapter)
                //  recyclerView.setLayoutManager(new LinearLayoutManager(context!!));
                recyclerView.setLayoutManager(
                    LinearLayoutManager(
                        context!!,
                        LinearLayoutManager.HORIZONTAL,
                        true
                    )
                )
            }))
        }))
        ex.shutdown()
        return view
    }

    private fun NewsetAyanSpans() {
        var Sbdetail: HashMap<String, String> = HashMap()
        var Swordbdetail: HashMap<String, SpannableString ?> = HashMap()
        val utils: Utils = Utils(getActivity())
        corpusSurahWord = utils.getCorpusWbwBySurahAyah(chapterid, ayanumber)
        val verbCorpuses: ArrayList<VerbCorpus> = utils.getQuranRootaAyah(chapterid, ayanumber)
        var index: Int = 1
        val nounCorpuses: ArrayList<NounCorpus> = utils.getQuranNounAyah(chapterid, ayanumber)
        for (corpusExpandWbwPOJO: NewCorpusExpandWbwPOJO in corpusSurahWord) {
            val qm: SentenceQuranMorphologyDetails = SentenceQuranMorphologyDetails(
                index,
                corpusSurahWord,
                nounCorpuses,
                verbCorpuses,
                context!!
            )
            Swordbdetail = qm.getWordDetails()
            if (!Swordbdetail.isEmpty()) {
                wordetailsall.put(index, Swordbdetail)
                //  this. Swordbdetail.clear();
            }
            if (!Sbdetail.isEmpty()) {
                //         verbdetailsall.put(index, Sbdetail);
                //    Sbdetail.clear();
            }
            index++
        }
        index = 1
        for (noun: NounCorpus in nounCorpuses) {
            val qm: SentenceQuranMorphologyDetails = SentenceQuranMorphologyDetails(
                index,
                corpusSurahWord,
                nounCorpuses,
                verbCorpuses,
                context!!
            )
            Swordbdetail = qm.getNoundetails()
            if (!Swordbdetail.isEmpty()) {
                if (wordetailsall.containsKey(noun.getWordno())) {
                    wordetailsall.get(noun.getWordno())!!.put("noun", Swordbdetail.get("noun"))
                    wordetailsall.get(noun.getWordno())!!.put("PCPL", Swordbdetail.get("pcpl"))
                    wordetailsall.get(noun.getWordno())!!.put("form", Swordbdetail.get("form"))
                    wordetailsall.get(noun.getWordno())!!.put("PART", Swordbdetail.get("PART"))
                }
            }
            //    if (!Swordbdetail.isEmpty()) {
            //       wordetailsall.put(index, Swordbdetail);
            //  this. Swordbdetail.clear();
            //    }
            if (!Sbdetail.isEmpty()) {
                //         verbdetailsall.put(index, Sbdetail);
                //    Sbdetail.clear();
            }
            index++
        }
        index = 1
        for (noun: VerbCorpus in verbCorpuses) {
            val qm: SentenceQuranMorphologyDetails = SentenceQuranMorphologyDetails(
                index,
                corpusSurahWord,
                nounCorpuses,
                verbCorpuses,
                context!!
            )
            Sbdetail = qm.getVerbDetails()
            for (s: Map.Entry<String, String> in Sbdetail.entries) {
                val value: String = s.value
                val key: String = s.key
                if ((key == "wordno")) {
                    val i: Int = value.toInt()
                    wordetailsall.get(i)!!.put(key, SpannableString .valueOf(value))
                }
                //   wordetailsall.put(s, value);
            }
            if (!Sbdetail.isEmpty()) {
                //      verbdetailsall.put(index, Sbdetail);
                verbdetailsall.put(noun.getWordno(), Sbdetail)
                //   wordetailsall.put(noun.getWordno(),Sbdetail);
            }
            index++
        }
        //  TreeMap<Integer, HashMap<String, String>> sorted = new TreeMap<>();
        //   sorted.putAll(verbdetailsall);
        //  sorted.putAll(wordetailsall);
        if (!corpusSurahWord.isEmpty()) {
            val quranverses: String = corpusSurahWord.get(0).getQurantext()
            spannable = SpannableString (quranverses)
            SetShart(utils)
            setHarfNasb(utils)
            SetMausoofSifa(utils)
            SetMudhaf(utils)
            SetKana(utils)
        }
    }

    protected fun setHarfNasb(utils: Utils) {
        val harfnasb: ArrayList<NewNasbEntity> =
            utils.getHarfNasbIndSurahAyahSnew(chapterid, ayanumber)
        for (nasb: NewNasbEntity in harfnasb) {
            //   harfinnaspanDark = new ForegroundColorSpan(GREEN);
            //    harfismspanDark = new ForegroundColorSpan(BCYAN);
            //   harfkhabarspanDark = new ForegroundColorSpan(YELLOW);
            if ((preferences == "dark") || (preferences == "blue")) {
                Constant.harfinnaspanDark = ForegroundColorSpan(Color.GREEN)
                Constant.harfismspanDark = ForegroundColorSpan(Constant.BCYAN)
                Constant.harfkhabarspanDark = ForegroundColorSpan(Color.YELLOW)
            } else {
                Constant.harfinnaspanDark = ForegroundColorSpan(Constant.WHOTPINK)
                Constant.harfismspanDark = ForegroundColorSpan(Constant.prussianblue)
                Constant.harfkhabarspanDark = ForegroundColorSpan(Constant.DeepPink)
            }
            val harfofverse: String = ""
            val ismofverse: String = ""
            val khabarofinna: String = ""
            val start: Int = nasb.getIndexstart()
            val end: Int = nasb.getIndexend()
            val ismstart: Int = nasb.getIsmstart()
            val ismend: Int = nasb.getIsmend()
            val khabarstart: Int = nasb.getKhabarstart()
            val khabarend: Int = nasb.getKhabarend()
            spannable!!.setSpan(
                Constant.harfinnaspanDark,
                start,
                end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannable!!.setSpan(
                Constant.harfismspanDark,
                ismstart,
                ismend,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannable!!.setSpan(
                Constant.harfkhabarspanDark,
                khabarstart,
                khabarend,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    protected fun SetMudhaf(utils: Utils) {
        val mudhafSurahAyah: ArrayList<NewMudhafEntity> =
            utils.getMudhafSurahAyahNew(chapterid, ayanumber)
        val jumlashart: String = "جملة شرطية"
        //  this.spannable = new SpannableString (quranverses);
        //  this.spannableHarf = new SpannableString (quranverses);
        for (mudhafEntity: NewMudhafEntity in mudhafSurahAyah) {
            Constant.mudhafspansDark = CorpusUtilityorig.getSpancolor(preferences, true)
            spannable!!.setSpan(
                Constant.mudhafspansDark,
                mudhafEntity.getStartindex(),
                mudhafEntity.getEndindex(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    protected fun SetMausoofSifa(utils: Utils) {
        val sifabySurahAyah: ArrayList<SifaEntity> = utils.getSifabySurahAyah(chapterid, ayanumber)
        //  String quranverses = corpusSurahWord.get(0).getQurantext();
        for (shartEntity: SifaEntity in sifabySurahAyah) {
            Constant.sifaspansDark = CorpusUtilityorig.getSpancolor(preferences, false)
            try {
                spannable!!.setSpan(
                    Constant.sifaspansDark,
                    shartEntity.getStartindex(),
                    shartEntity.getEndindex(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            } catch (e: IndexOutOfBoundsException) {
                //           System.out.println(shartEntity.getSurah() + "  " + shartEntity.getAyah() + "  " + quranverses);
            }
        }
    }

    protected fun SetShart(utils: Utils) {
        val shart: ArrayList<NewShartEntity> = utils.getShartSurahAyahNew(chapterid, ayanumber)
        //  this.spannable = new SpannableString (quranverses);
        var spannable: SpannableString ?
        for (shartEntity: NewShartEntity in shart) {
            prefs =
                PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.context!!)
            preferences = prefs.getString("theme", "dark")
            Constant.harfshartspanDark = ForegroundColorSpan(Constant.GOLD)
            Constant.shartspanDark = ForegroundColorSpan(Color.GREEN)
            Constant.jawabshartspanDark = ForegroundColorSpan(Color.CYAN)
            if ((preferences == "dark") || (preferences == "blue")) {
                Constant.harfshartspanDark = ForegroundColorSpan(Constant.GOLD)
                Constant.shartspanDark = ForegroundColorSpan(Constant.ORANGE400)
                Constant.jawabshartspanDark = ForegroundColorSpan(Color.CYAN)
            } else {
                Constant.harfshartspanDark = ForegroundColorSpan(Constant.FORESTGREEN)
                Constant.shartspanDark = ForegroundColorSpan(Constant.GREENDARK)
                Constant.jawabshartspanDark = ForegroundColorSpan(Constant.WHOTPINK)
            }
            this.spannable!!.setSpan(
                Constant.harfshartspanDark,
                shartEntity.getIndexstart(),
                shartEntity.getIndexend(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            this.spannable!!.setSpan(
                Constant.shartspanDark,
                shartEntity.getShartindexstart(),
                shartEntity.getShartindexend(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            this.spannable!!.setSpan(
                Constant.jawabshartspanDark,
                shartEntity.getJawabshartindexstart(),
                shartEntity.getJawabshartindexend(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    protected fun SetKana(utils: Utils) {
        val kana: ArrayList<NewKanaEntity> = utils.getKanaSurahAyahnew(chapterid, ayanumber)
        //  this.spannable = new SpannableString (quranverses);
        for (kanaEntity: NewKanaEntity in kana) {
            Constant.harfshartspanDark = ForegroundColorSpan(Constant.GOLD)
            Constant.shartspanDark = ForegroundColorSpan(Color.GREEN)
            Constant.jawabshartspanDark = ForegroundColorSpan(Color.CYAN)
            spannable!!.setSpan(
                Constant.harfshartspanDark,
                kanaEntity.getIndexstart(),
                kanaEntity.getIndexend(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannable!!.setSpan(
                Constant.shartspanDark,
                kanaEntity.getIsmkanastart(),
                kanaEntity.getIsmkanaend(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannable!!.setSpan(
                Constant.jawabshartspanDark,
                kanaEntity.getKhabarstart(),
                kanaEntity.getKhabarend(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    /*

     */
    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sentenceRootWordDisplayAdapter!!.SetOnItemClickListener(object : OnItemClickListener {
            public override fun onItemClick(v: View, position: Int) {
                val actulaposition: Int = position + 1
                var text: CharSequence? = null
                var text2: CharSequence? = null
                val viewVerbConjugation: View? = v.findViewById(R.id.verbconjugationbtn)
                val verboccuranceid: View? = v.findViewById(R.id.verboccurance)
                val nouns: View? = v.findViewById(R.id.wordoccurance)
                val verse: View? = v.findViewById(R.id.spannableverse)
                val wordview: View? = v.findViewById(R.id.wordView)
                val formview: View = v.findViewById(R.id.mazeedmeaning)
                var ismujarrad: Boolean = false
                var ismazeed: Boolean = false
                var root: String? = wordetailsall.get(actulaposition)!!.get("root").toString()
                if (finalverbdetail!!.get(actulaposition) != null) {
                    ismujarrad = !(finalverbdetail!!.get(actulaposition)!!.get("wazan") == "null")
                    ismazeed = !(finalverbdetail!!.get(actulaposition)!!.get("form") == "null")
                }
                val dataBundle: Bundle = Bundle()
                var intkey: Int = 0
                val verbmood: String = ""
                val mazeedwazan: String = ""
                val isparticple: Boolean = wordetailsall.get(actulaposition)!!.get("PART") != null
                val isconjugation: Boolean = ismujarrad || ismazeed || isparticple
                val isroot: Boolean = wordetailsall.get(actulaposition)!!.get("root") != null
                val quadrilateral: Boolean = false
                val isnoun: Boolean =
                    ((wordetailsall.get(actulaposition)!!.get("tag").toString()) == "N")
                if ((wordetailsall.get(actulaposition)!!.get("tag").toString() == "V")) {
                    val wordno: String =
                        wordetailsall.get(actulaposition)!!.get("wordno").toString()
                    //    String wordno = finalverbdetail.get(actulaposition).get(wordetailsall.get(actulaposition).get("wordno"));
                    intkey = wordno.toInt()
                    if ((wordetailsall.get(actulaposition)!!.get("form").toString() == "null")) {
                        val mujarradwazan: String =
                            finalverbdetail!!.get(intkey)!!.get("wazan").toString()
                        root = finalverbdetail!!.get(intkey)!!.get("root").toString()
                        ismazeed = false
                        ismujarrad = true
                        vb = VerbWazan()
                        vb!!.setRoot(root)
                        vb!!.setWazan(mujarradwazan)
                        dataBundle.putString(
                            Constant.VERBMOOD, finalverbdetail!!.get(intkey)!!
                                .get("verbmood").toString()
                        )
                        dataBundle.putString(
                            Constant.QURAN_VERB_WAZAN,
                            VerbWazan.Companion.getWazan()
                        )
                        dataBundle.putString(Constant.QURAN_VERB_ROOT, root)
                    } else {
                        ismazeed = true
                        ismujarrad = false
                        vb = VerbWazan()
                        vb!!.setRoot(finalverbdetail!!.get(intkey)!!.get("root").toString())
                        vb!!.setWazan(finalverbdetail!!.get(intkey)!!.get("form").toString())
                        dataBundle.putString(
                            Constant.QURAN_VERB_WAZAN,
                            VerbWazan.Companion.getWazan()
                        )
                        dataBundle.putString(Constant.QURAN_VERB_ROOT, vb!!.getRoot())
                        dataBundle.putString(
                            Constant.VERBMOOD, finalverbdetail!!.get(intkey)!!
                                .get("verbmood").toString()
                        )
                    }
                    finalverbdetail!!.get(intkey)!!.get("verbmood")
                }
                if (isparticple) {
                    vb = VerbWazan()
                    if ((wordetailsall.get(actulaposition)!!.get("form").toString() == "I")) {
                        val databaseUtils: DatabaseUtils = DatabaseUtils(getActivity())
                        val triVerb: ArrayList<MujarradVerbs> = databaseUtils.getMujarradVerbs(root)
                        if (!triVerb.isEmpty()) {
                            this.participles = true
                            //   ismfaelmafool = GatherAll.getInstance().getMujarradParticiple(root, triVerb.get(0).getBab());
                            vb!!.setWazan(triVerb.get(0).getBab())
                        }
                        ismujarrad = true
                    } else {
                        vb!!.setWazan(wordetailsall.get(actulaposition)!!.get("form").toString())
                        ismazeed = true
                    }
                    vb!!.setRoot(wordetailsall.get(actulaposition)!!.get("root").toString())
                    dataBundle.putString(Constant.QURAN_VERB_WAZAN, VerbWazan.Companion.getWazan())
                    dataBundle.putString(Constant.QURAN_VERB_ROOT, vb!!.getRoot())
                    dataBundle.putString(Constant.VERBMOOD, "Indicative")
                }
                if (isnoun && !isParticiples) {
                    vb = VerbWazan()
                    vb!!.setRoot(wordetailsall.get(actulaposition)!!.get("root").toString())
                    dataBundle.putString(Constant.QURAN_VERB_WAZAN, " ")
                    dataBundle.putString(Constant.QURAN_VERB_ROOT, vb!!.getRoot())
                    dataBundle.putString(Constant.VERBMOOD, "")
                }
                if (viewVerbConjugation != null) {
                    text = (viewVerbConjugation as MaterialButton).getText()
                    if ((text.toString() == "Click for Verb Conjugation")) {
                        if (isroot && isconjugation) {
                            //      ArrayList arrayList = ThulathiMazeedConjugatonList.get(actulaposition);
                            //   arrayList.get(0).ge
                            if (ismujarrad) {
                                dataBundle.putString(Constant.VERBTYPE, "mujarrad")
                            } else if (ismazeed) {
                                dataBundle.putString(Constant.VERBTYPE, "mazeed")
                            }
                            val intent: Intent =
                                Intent(getActivity(), ConjugatorTabsActivity::class.java)
                            intent.putExtras(dataBundle)
                            startActivity(intent)
                        }
                    }
                } else if (wordview != null) {
                    if (quadrilateral) {
                        dataBundle.putString(Constant.QURAN_VERB_ROOT, vb!!.getRoot())
                        dataBundle.putString(Constant.QURAN_VERB_WAZAN, " ")
                        dataBundle.putString("arabicword", "")
                    }
                    if (isroot && isconjugation || isnoun) {
                        try {
                            if (ismujarrad) {
                                dataBundle.putString(Constant.VERBTYPE, "mujarrad")
                                dataBundle.putString("arabicword", "")
                            } else if (ismazeed) {
                                dataBundle.putString(Constant.VERBTYPE, "mazeed")
                                dataBundle.putString("arabicword", "")
                            } else {
                                dataBundle.putString(Constant.VERBTYPE, "")
                                dataBundle.putString("arabicword", "")
                            }
                            val intent: Intent =
                                Intent(getActivity(), LughatWordDetailsAct::class.java)
                            intent.putExtras(dataBundle)
                            startActivity(intent)
                        } catch (e: NullPointerException) {
                            println("null pointer")
                        }
                    } else {
                        Toast.makeText(context!!, "not found", Toast.LENGTH_SHORT).show()
                    }
                } else if (verse != null) {
                    val item: GrammerFragmentsBottomSheet = GrammerFragmentsBottomSheet()
                    //    item.setdata(rootWordMeanings,wbwRootwords,grammarRootsCombined);
                    val fragmentManager: FragmentManager =
                        getActivity()!!.getSupportFragmentManager()
                    dataBundle.putInt(Constant.SURAH_ID, chapterid)
                    dataBundle.putInt(Constant.AYAHNUMBER, ayanumber)
                    item.setArguments(dataBundle)
                    val data: Array<String> = arrayOf(chapterid.toString(), ayanumber.toString())
                    val transactions: FragmentTransaction =
                        fragmentManager.beginTransaction().setCustomAnimations(
                            anim.abc_slide_in_top, android.R.anim.fade_out
                        )
                    //   transactions.show(item);
                    GrammerFragmentsBottomSheet.Companion.newInstance(data).show(
                        (getActivity()!!.getSupportFragmentManager()),
                        WordAnalysisBottomSheet.Companion.TAG
                    )
                } else if (nouns != null) {
                    val bundle: Bundle = Bundle()
                    //   Intent intent = new Intent(getActivity(), NounOccuranceAsynKAct.class);
                    val intent: Intent = Intent(getActivity(), WordOccuranceAct::class.java)
                    try {
                        if (vb!!.getRoot() != null) {
                            bundle.putString(Constant.QURAN_VERB_ROOT, vb!!.getRoot())
                        } else if (harfNasbAndZarf != null) {
                            bundle.putString(Constant.QURAN_VERB_ROOT, harfNasbAndZarf)
                        }
                    } catch (e1: NullPointerException) {
                        bundle.putString(Constant.QURAN_VERB_ROOT, harfNasbAndZarf)
                        e1.printStackTrace()
                    }
                    intent.putExtras(bundle)
                    //   intent.putExtra(QURAN_VERB_ROOT,vb.getRoot());
                    startActivity(intent)
                } else if (verboccuranceid != null) {
                    text2 = (verboccuranceid as MaterialButton).getText()
                    if ((text2.toString() == "Click for Verb Occurance"));
                    run({
                        if (!(vb == null)) {
                            val bundle: Bundle = Bundle()
                            val intent: Intent = Intent(getActivity(), WordOccuranceAct::class.java)
                            bundle.putString(Constant.QURAN_VERB_ROOT, vb!!.getRoot())
                            intent.putExtras(bundle)
                            //   intent.putExtra(QURAN_VERB_ROOT,vb.getRoot());
                            startActivity(intent)
                        }
                    })
                }
            }

            private fun getFormDetails(form: String): String {
                return (Constant.mazeedsignificance.get(form))!!
            }
        })
    }

    companion object {
        val TAG: String = "bottom"

        // TODO: Customize parameter argument names
        private val ARG_OPTIONS_DATA: String = "options_data"

        // TODO: Customize parameters
        fun newInstance(data: Array<String?>?): SentenceAnalysisBottomSheet {
            val fragment: SentenceAnalysisBottomSheet = SentenceAnalysisBottomSheet()
            val args: Bundle = Bundle()
            args.putStringArray(SentenceAnalysisBottomSheet.Companion.ARG_OPTIONS_DATA, data)
            fragment.setArguments(args)
            return fragment
        }
    }
}