package com.example.mushafconsolidated.fragmentsimport

import android.content.Context
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import com.example.mushafconsolidated.Entities.NewCorpusExpandWbwPOJO
import com.example.mushafconsolidated.Entities.NounCorpus
import com.example.mushafconsolidated.Entities.VerbCorpus
import com.example.utility.CorpusConstants
import com.example.utility.CorpusConstants.verbfeaturesenglisharabic


class SentenceQuranMorphologyDetails constructor(
    index: Int,
    corpusSurahWord: ArrayList<NewCorpusExpandWbwPOJO>,
    corpusNounWord: ArrayList<NounCorpus>, verbCorpuses: ArrayList<VerbCorpus>,
    context: Context
) : QuranMorphologyDetails() {
    private val context: Context
    var form: Int = 0
    var Thulathi: String? = null
    private val index: Int
    private val corpusNoun: ArrayList<NounCorpus>
    private val indigo: Int = 0
    private val cyan: Int = 0
    private val yellow: Int = 0
    private val green: Int = 0
    private val corpusSurahWord: ArrayList<NewCorpusExpandWbwPOJO>
    private val verbcorpusform: ArrayList<VerbCorpus>

    init {
        this.index = index - 1
        this.corpusSurahWord = corpusSurahWord
        this.verbcorpusform = verbCorpuses
        this.corpusNoun = corpusNounWord
        this.context = context
    }

    public override fun setThulathi(thulathi: String?) {
        Thulathi = thulathi
    }

    public override fun getForm(): Int {
        return form
    }

    public override fun setForm(form: Int) {
        this.form = form
    }

    public override fun getVerbDetails(): HashMap<String, String?> {
        val vbdetail: HashMap<String, String?> = HashMap()
        vbdetail.put("surahid", verbcorpusform.get(index).getChapterno().toString())
        vbdetail.put("ayahid", verbcorpusform.get(index).getVerseno().toString())
        vbdetail.put("wordno", verbcorpusform.get(index).getWordno().toString())
        var roots: String?
        roots = verbRoot
        roots = verbCorpusRoot
        vbdetail.put("root", roots)
        if (verbcorpusform.size > 0) {
            if (!(verbcorpusform.get(index).getForm() == "I")) {
                val mform: String = verbcorpusform.get(index).getForm()
                convertForms(mform)
                vbdetail.put("form", getForm().toString())
                vbdetail.put("wazan", "null")
                //    setSarfSagheer(true);
                //  mazeedQuery = sm.getMazeedQuery(roots, getForm());
            } else {
                val thulathibab: String = verbcorpusform.get(index).getThulathibab()
                if (thulathibab.length == 0) vbdetail.put(
                    "thulathi",
                    "null"
                ) else if (thulathibab.length == 1) {
                    val s: String = verbcorpusform.get(index).getThulathibab()
                    val sb: String  = QuranMorphologyDetails.Companion.getThulathiName(s)
                    vbdetail.put("thulathi", sb.toString())
                    vbdetail.put("wazan", thulathibab)
                    vbdetail.put("form", "null")
                } else if (thulathibab.length > 1) {
                    val s: String = thulathibab.substring(0, 1)
                    val sb: String  = QuranMorphologyDetails.Companion.getThulathiName(s)
                    vbdetail.put("thulathi", sb.toString())
                    vbdetail.put("wazan", s)
                }
            }
        }
        val gendernumber: String = verbcorpusform.get(index).getGendernumber()
        val pngsb: String  =
            QuranMorphologyDetails.Companion.getGenderNumberdetails(gendernumber)
        if (vbdetail.get("form") != null) {
            val formdetails: String =
                QuranMorphologyDetails.Companion.getFormName(verbcorpusform.get(index).getForm())
            pngsb.append("," + "(form").append(formdetails)
            //     pngsb.append("," + "(form").append(verbcorpusform.get(index).getForm()).append(")");
            vbdetail.put("png", pngsb.toString())
        } else {
            vbdetail.put("png", null)
            //    pngsb.append(",").append(verbcorpusform.get(index).getThulathibab());
        }
        vbdetail.put("png", pngsb.toString())
        val tense: String = verbcorpusform.get(index).getTense()
        when (tense) {
            "IMPF" -> vbdetail.put("tense", verbfeaturesenglisharabic.IMPF)
            "IMPV" -> vbdetail.put("tense", verbfeaturesenglisharabic.IMPV)
            "PERF" -> vbdetail.put("tense", verbfeaturesenglisharabic.PERF)
        }
        val voice: String = verbcorpusform.get(index).getVoice()
        when (voice) {
            "ACT" -> vbdetail.put("voice", verbfeaturesenglisharabic.ACT)
            "PASS" -> vbdetail.put("voice", verbfeaturesenglisharabic.PASS)
        }
        if ((roots == "كون")) {
            val kana_mood: String = verbcorpusform.get(index).getKana_mood()
            when (kana_mood) {
                "MOOD:SUBJ" -> {
                    vbdetail.put("mood", verbfeaturesenglisharabic.IND)
                    vbdetail.put("verbmood", "Indicative")
                    vbdetail.put("mood", verbfeaturesenglisharabic.JUS)
                    vbdetail.put("verbmood", "Jussive")
                }

                "JUS" -> {
                    vbdetail.put("mood", verbfeaturesenglisharabic.JUS)
                    vbdetail.put("verbmood", "Jussive")
                }

                "SUBJ" -> {
                    vbdetail.put("mood", verbfeaturesenglisharabic.SUBJ)
                    vbdetail.put("verbmood", "Subjunctive")
                }

                else -> {
                    vbdetail.put("mood", verbfeaturesenglisharabic.IND)
                    vbdetail.put("verbmood", "Indicative")
                }
            }
        } else {
            val mood: String = verbcorpusform.get(index).getMood_kananumbers()
            when (mood) {
                "IND" -> {
                    vbdetail.put("mood", verbfeaturesenglisharabic.IND)
                    vbdetail.put("verbmood", "Indicative")
                    vbdetail.put("mood", verbfeaturesenglisharabic.JUS)
                    vbdetail.put("verbmood", "Jussive")
                }

                "JUS" -> {
                    vbdetail.put("mood", verbfeaturesenglisharabic.JUS)
                    vbdetail.put("verbmood", "Jussive")
                }

                "SUBJ" -> {
                    vbdetail.put("mood", verbfeaturesenglisharabic.SUBJ)
                    vbdetail.put("verbmood", "Subjunctive")
                }
            }
        }
        vbdetail.put("lemma", verbcorpusform.get(index).getLemma_a())
        return vbdetail
    }

    private val verbCorpusRoot: String?
        private get() {
            var roots: String? = null
            roots = verbcorpusform.get(index).getRoot_a()
            return roots
        }
    private val verbRoot: String?
        private get() {
            var roots: String? = null
            if (corpusSurahWord.get(index).getWordcount() == 1) {
                if ((corpusSurahWord.get(index).getTagone() == "V")) {
                    roots = corpusSurahWord.get(index).getRoot_a()
                }
            } else if (corpusSurahWord.get(index).getWordcount() == 2) {
                if ((corpusSurahWord.get(index).getTagone() == "V")) {
                    roots = corpusSurahWord.get(index).getRootaraone()
                } else if ((corpusSurahWord.get(index).getTagtwo() == "V")) {
                    roots = corpusSurahWord.get(index).getRootaratwo()
                }
            } else if (corpusSurahWord.get(index).getWordcount() == 3) {
                if ((corpusSurahWord.get(index).getTagone() == "V")) {
                    roots = corpusSurahWord.get(index).getRootaraone()
                } else if ((corpusSurahWord.get(index).getTagtwo() == "V")) {
                    roots = corpusSurahWord.get(index).getRootaratwo()
                } else if ((corpusSurahWord.get(index).getTagthree() == "V")) {
                    roots = corpusSurahWord.get(index).getRootarathree()
                }
            } else if (corpusSurahWord.get(index).getWordcount() == 4) {
                if ((corpusSurahWord.get(index).getTagone() == "V")) {
                    roots = corpusSurahWord.get(index).getRootaraone()
                } else if ((corpusSurahWord.get(index).getTagtwo() == "V")) {
                    roots = corpusSurahWord.get(index).getRootaratwo()
                } else if ((corpusSurahWord.get(index).getTagthree() == "V")) {
                    roots = corpusSurahWord.get(index).getRootarathree()
                } else if ((corpusSurahWord.get(index).getTagfour() == "V")) {
                    roots = corpusSurahWord.get(index).getRootarafour()
                }
            } else if (corpusSurahWord.get(index).getWordcount() == 5) {
                if ((corpusSurahWord.get(index).getTagone() == "V")) {
                    roots = corpusSurahWord.get(index).getRootaraone()
                } else if ((corpusSurahWord.get(index).getTagtwo() == "V")) {
                    roots = corpusSurahWord.get(index).getRootaratwo()
                } else if ((corpusSurahWord.get(index).getTagthree() == "V")) {
                    roots = corpusSurahWord.get(index).getRootarathree()
                } else if ((corpusSurahWord.get(index).getTagfour() == "V")) {
                    roots = corpusSurahWord.get(index).getRootarafour()
                } else if ((corpusSurahWord.get(index).getTagfive() == "V")) {
                    roots = corpusSurahWord.get(index).getRootarafive()
                }
            }
            return roots
        }//   String form = corpusNoun.get(0).getForm();

    //   String mform = corpusNoun.get(0).getForm();
    /*
        if (corpusNoun.size() > 0) {
            if (corpusNoun.get(index).getProptwo().equals(CorpusConstants.NominalsProp.PCPL)) {
                String form = corpusNoun.get(index).getForm();


                final String mform = form.replaceAll("\\(|\\)", "");

                //   String mform = corpusNoun.get(0).getForm();

                if (!mform.equals("I")) {
                    convertForms(mform);
                    wordbdetail.put("form", SpannableString .valueOf(String.valueOf(getForm())));

                    getRoot(corpusSurahWord, wordbdetail);
                } else {
                    if (corpusNoun.get(index).getProptwo().equals("PCPL")) {
                        wordbdetail.put("PCPL", SpannableString .valueOf(corpusNoun.get(index).getPropone().concat(corpusNoun.get(index).getProptwo())));
                    } else {
                        wordbdetail.put("PCPL", SpannableString .valueOf("NONE"));
                    }


                }

            }
        }
       */
    val noundetails: HashMap<String, SpannableString ?>
        get() {
            val wordbdetail: HashMap<String, SpannableString ?> = HashMap()
            val sb: String  = String ()

            /*
                 if (corpusNoun.size() > 0) {
                     if (corpusNoun.get(index).getProptwo().equals(CorpusConstants.NominalsProp.PCPL)) {
                         String form = corpusNoun.get(index).getForm();
         
         
                         final String mform = form.replaceAll("\\(|\\)", "");
         
                         //   String mform = corpusNoun.get(0).getForm();
         
                         if (!mform.equals("I")) {
                             convertForms(mform);
                             wordbdetail.put("form", SpannableString .valueOf(String.valueOf(getForm())));
         
                             getRoot(corpusSurahWord, wordbdetail);
                         } else {
                             if (corpusNoun.get(index).getProptwo().equals("PCPL")) {
                                 wordbdetail.put("PCPL", SpannableString .valueOf(corpusNoun.get(index).getPropone().concat(corpusNoun.get(index).getProptwo())));
                             } else {
                                 wordbdetail.put("PCPL", SpannableString .valueOf("NONE"));
                             }
         
         
                         }
         
                     }
                 }
                */if (corpusNoun.size > 0) {
                if ((corpusNoun.get(index).getProptwo() == CorpusConstants.NominalsProp.PCPL)) {
                    val form: String = corpusNoun.get(index).getForm()
                    //   String form = corpusNoun.get(0).getForm();
                    val mform: String = form.replace("\\(|\\)".toRegex(), "")
                    //   String mform = corpusNoun.get(0).getForm();
                    wordbdetail.put("PART", SpannableString .valueOf("PCPL"))
                    if ((mform == "I")) {
                        wordbdetail.put("form", SpannableString .valueOf(form))
                    }
                    if (!(mform == "I")) {
                        if (!(mform == "null")) {
                            convertForms(mform)
                            wordbdetail.put(
                                "form",
                                SpannableString .valueOf(getForm().toString())
                            )
                            getRoot(corpusSurahWord, wordbdetail)
                        }
                    } else {
                        if ((corpusNoun.get(index).getProptwo() == "PCPL")) {
                            wordbdetail.put(
                                "PCPL",
                                SpannableString .valueOf(
                                    corpusNoun.get(index).getPropone() + corpusNoun.get(index)
                                        .getProptwo()
                                )
                            )
                            wordbdetail.put("PART", SpannableString .valueOf("PCPL"))
                            wordbdetail.put("particple", SpannableString .valueOf("PART"))
                            wordbdetail.put("form", SpannableString .valueOf("I"))
                        } else {
                            wordbdetail.put("PART", SpannableString .valueOf("NONE"))
                            wordbdetail.put("particple", SpannableString .valueOf("PART"))
                            wordbdetail.put("form", SpannableString .valueOf("I"))
                        }
                    }
                }
            }
            if (corpusNoun.size > 0) {
                if ((corpusNoun.get(index).getTag() == "N")) {
                    val propone: String = corpusNoun.get(index).getPropone()
                    val proptwo: String = corpusNoun.get(index).getProptwo()
                    var pcpl: String = ""
                    if (!(propone == "null") && !(proptwo == "null")) {
                        pcpl = pcpl + propone + proptwo
                    }
                    val form: String = corpusNoun.get(index).getForm()
                    val gendernumber: String = corpusNoun.get(index).getGendernumber()
                    val type: String = corpusNoun.get(index).getType()
                    val cases: String = corpusNoun.get(index).getCases()
                    sb.append("Noun:")
                    if (!(cases == "null")) {
                        when (cases) {
                            "NOM" -> sb.append(CorpusConstants.NominalsProp.NOM + " ")
                            "ACC" -> sb.append(CorpusConstants.NominalsProp.ACC + " ")
                            "GEN" -> sb.append(CorpusConstants.NominalsProp.GEN + " ")
                        }
                    }
                    if (!(gendernumber == "null")) {
                        if (gendernumber.length == 1) {
                            when (gendernumber) {
                                "M" -> sb.append(CorpusConstants.png.M)
                                "F" -> sb.append(CorpusConstants.png.F)
                                "P" -> sb.append(CorpusConstants.png.P)
                            }
                        } else if (gendernumber.length == 2) {
                            val gender: String = gendernumber.substring(0, 1)
                            val number: String = gendernumber.substring(1, 2)
                            when (gender) {
                                "M" -> sb.append(CorpusConstants.png.M + " ")
                                "F" -> sb.append(CorpusConstants.png.F + " ")
                            }
                            when (number) {
                                "P" -> sb.append(CorpusConstants.png.P + " ")
                                "S" -> sb.append(CorpusConstants.png.S + " ")
                                "D" -> sb.append(CorpusConstants.png.D + " ")
                            }
                        }
                    }
                    if (!(form == "null")) {
                        sb.append("(form").append(form).append(")")
                    }
                    if (!(propone == "null") && !(proptwo == "null")) {
                        if ((pcpl == "ACTPCPL")) {
                            sb.append(CorpusConstants.NominalsProp.ACTPCPL)
                            wordbdetail.put("particple", SpannableString .valueOf("PART"))
                        } else if ((pcpl == "PASSPCPL")) {
                            sb.append(CorpusConstants.NominalsProp.PASSPCPL)
                            wordbdetail.put("particple", SpannableString .valueOf("PART"))
                        }
                    }
                    if (!(type == "null")) {
                        sb.append(CorpusConstants.NominalsProp.INDEF)
                        sb.append(",")
                    }
                    if (sb.length > 5) {
                        wordbdetail.put("noun", SpannableString .valueOf(sb.toString()))
                    }
                }
            }
            getProperNounDetails(corpusNoun, wordbdetail, sb)
            return wordbdetail
        }

    public override fun getWordDetails(): HashMap<String, SpannableString ?> {
        val wordbdetail: HashMap<String, SpannableString ?> = HashMap()
        val surah: Int = corpusSurahWord.get(index).getSurah()
        wordbdetail.put(
            "surahid",
            SpannableString .valueOf(corpusSurahWord.get(index).getSurah().toString())
        )
        wordbdetail.put(
            "ayahid",
            SpannableString .valueOf(corpusSurahWord.get(index).getAyah().toString())
        )
        wordbdetail.put(
            "wordno",
            SpannableString .valueOf(corpusSurahWord.get(index).getWordno().toString())
        )
        wordbdetail.put(
            "wordtranslation",
            SpannableString .valueOf(corpusSurahWord.get(index).getEn())
        )
        val arabicword: String = corpusSurahWord.get(index).getAraone() + corpusSurahWord.get(index)
            .getAratwo() + corpusSurahWord.get(index).getArathree()
        +corpusSurahWord.get(index).getArafour() + corpusSurahWord.get(index).getArafour()
        if (corpusNoun.size > 0) {
            if ((corpusNoun.get(0).getProptwo() == CorpusConstants.NominalsProp.PCPL)) {
                val form: String = corpusNoun.get(0).getForm()
                val mform: String = form.replace("\\(|\\)".toRegex(), "")
                //   String mform = corpusNoun.get(0).getForm();
                if (!(mform == "I")) {
                    convertForms(mform)
                    wordbdetail.put("form", SpannableString .valueOf(getForm().toString()))
                    getRoot(corpusSurahWord, wordbdetail)
                } else {
                    if ((corpusNoun.get(0).getProptwo() == "PCPL")) {
                        wordbdetail.put(
                            "PCPL",
                            SpannableString .valueOf(
                                corpusNoun.get(0).getPropone() + corpusNoun.get(0).getProptwo()
                            )
                        )
                        wordbdetail.put("particple", SpannableString .valueOf("PART"))
                    } else {
                        wordbdetail.put("PCPL", SpannableString .valueOf("NONE"))
                        wordbdetail.put("particple", SpannableString .valueOf("PART"))
                    }
                }
            }
        }
        val size: Int = corpusNoun.size
        val corpousindex: Int = 0
        GetPronounDetails(corpusSurahWord, wordbdetail)
        GetLemmArabicwordWordDetails(corpusSurahWord, wordbdetail)
        val sb: String  = String ()
        //get the root,since vercopus is not checked
        getRoot(corpusSurahWord, wordbdetail)
        // getProperNounDetails(corpusNoun, wordbdetail, sb);
        return wordbdetail
    }

    private fun getProperNounDetails(
        corpusNoun: ArrayList<NounCorpus>,
        wordbdetail: HashMap<String, SpannableString ?>,
        sb: String 
    ) {
        if (corpusNoun.size > 0) {
            if ((corpusNoun.get(index).getTag() == "PN") || (corpusNoun.get(index)
                    .getTag() == "ADJ")
            ) {
                val propone: String = corpusNoun.get(index).getPropone()
                val proptwo: String = corpusNoun.get(index).getProptwo()
                var pcpl: String = ""
                if (!(propone == "null") && !(proptwo == "null")) {
                    pcpl = pcpl + propone + proptwo
                }
                if ((corpusNoun.get(index).getPropone() == "VN")) {
                    sb.append("Proper/Verbal Noun")
                } else if ((corpusNoun.get(index).getTag() == "ADJ")) {
                    sb.append("Adjective:")
                } else {
                    sb.append("Proper Noun:")
                }
                val form: String = corpusNoun.get(index).getForm()
                val gendernumber: String = corpusNoun.get(index).getGendernumber()
                val type: String = corpusNoun.get(index).getType()
                val cases: String = corpusNoun.get(index).getCases()
                // sb.append("Proper Noun:");
                if (!(cases == "null")) {
                    when (cases) {
                        "NOM" -> sb.append(CorpusConstants.NominalsProp.NOM)
                        "ACC" -> sb.append(CorpusConstants.NominalsProp.ACC)
                        "GEN" -> sb.append(CorpusConstants.NominalsProp.GEN)
                    }
                }
                if (!(gendernumber == "null")) {
                    if (gendernumber.length == 1) {
                        when (gendernumber) {
                            "M" -> sb.append(CorpusConstants.png.M + " ")
                            "F" -> sb.append(CorpusConstants.png.F + " ")
                            "P" -> sb.append(CorpusConstants.png.P + " ")
                        }
                    } else if (gendernumber.length == 2) {
                        val gender: String = gendernumber.substring(0, 1)
                        val number: String = gendernumber.substring(1, 2)
                        when (gender) {
                            "M" -> sb.append(CorpusConstants.png.M + " ")
                            "F" -> sb.append(CorpusConstants.png.F + " ")
                        }
                        when (number) {
                            "P" -> sb.append(CorpusConstants.png.P + " ")
                            "S" -> sb.append(CorpusConstants.png.S + " ")
                            "D" -> sb.append(CorpusConstants.png.D + " ")
                        }
                    }
                }
                if (!(form == "null")) {
                    sb.append("(form ").append(form).append(")")
                }
                if (!(propone == "null") && !(proptwo == "null")) {
                    if ((pcpl == "ACTPCPL")) {
                        sb.append(CorpusConstants.NominalsProp.ACTPCPL)
                    } else if ((pcpl == "PASSPCPL")) {
                        sb.append(CorpusConstants.NominalsProp.PASSPCPL)
                    }
                }
                if (!(type == "null")) {
                    sb.append(CorpusConstants.NominalsProp.INDEF)
                    sb.append(",")
                }
                if (sb.length > 5) {
                    wordbdetail.put("noun", SpannableString .valueOf(sb.toString()))
                }
            }
        }
    }

    private fun getRoot(
        corpusSurahWord: ArrayList<NewCorpusExpandWbwPOJO>,
        wordbdetail: HashMap<String, SpannableString ?>
    ) {
        val wordno: Int = corpusSurahWord.get(index).getWordno()
        for (verb: VerbCorpus in verbcorpusform) {
            if (verb.getWordno() == wordno && ((verb.getVoice() == "ACTI") || (verb.getVoice() == "PASS"))) {
                if (!(verb.getForm() == "I")) {
                    val mform: String = verb.getForm()
                    convertForms(mform)
                    wordbdetail.put("form", SpannableString .valueOf(getForm().toString()))
                    wordbdetail.put("wazan", SpannableString .valueOf("null"))
                    //    setSarfSagheer(true);
                    //  mazeedQuery = sm.getMazeedQuery(roots, getForm());
                } else {
                    val thulathibab: String = verb.getThulathibab()
                    if (thulathibab.length == 0) wordbdetail.put(
                        "thulathi",
                        null
                    ) else if (thulathibab.length == 1) {
                        val s: String = verb.getThulathibab()
                        val sb: String  = QuranMorphologyDetails.Companion.getThulathiName(s)
                        wordbdetail.put("thulathi", SpannableString .valueOf(sb.toString()))
                        wordbdetail.put("wazan", SpannableString .valueOf(thulathibab))
                        wordbdetail.put("form", SpannableString .valueOf("null"))
                    } else if (thulathibab.length > 1) {
                        val s: String = thulathibab.substring(0, 1)
                        val sb: String  = QuranMorphologyDetails.Companion.getThulathiName(s)
                        wordbdetail.put("thulathi", SpannableString .valueOf(sb.toString()))
                        wordbdetail.put("wazan", SpannableString .valueOf(s))
                        wordbdetail.put("form", SpannableString .valueOf("null"))
                    }
                }
                val gendernumber: String = verb.getGendernumber()
                val pngsb: String  =
                    QuranMorphologyDetails.Companion.getGenderNumberdetails(gendernumber)
                if (wordbdetail.get("form") != null) {
                    val formdetails: String = verb.getForm()
                    pngsb.append("," + "(form").append(formdetails)
                    //     pngsb.append("," + "(form").append(verbcorpusform.get(index).getForm()).append(")");
                    wordbdetail.put("png", SpannableString .valueOf(pngsb.toString()))
                } else {
                    wordbdetail.put("png", null)
                    //    pngsb.append(",").append(verbcorpusform.get(index).getThulathibab());
                }
                wordbdetail.put("png", SpannableString .valueOf(pngsb.toString()))
                val tense: String = verb.getTense()
                when (tense) {
                    "IMPF" -> wordbdetail.put(
                        "tense",
                        SpannableString .valueOf(verbfeaturesenglisharabic.IMPF)
                    )

                    "IMPV" -> wordbdetail.put(
                        "tense", SpannableString .valueOf(
                            verbfeaturesenglisharabic.IMPV
                        )
                    )

                    "PERF" -> wordbdetail.put(
                        "tense", SpannableString .valueOf(
                            verbfeaturesenglisharabic.PERF
                        )
                    )
                }
                val voice: String = verb.getVoice()
                when (voice) {
                    "ACT" -> wordbdetail.put(
                        "voice", SpannableString .valueOf(
                            verbfeaturesenglisharabic.ACT
                        )
                    )

                    "PASS" -> wordbdetail.put(
                        "voice", SpannableString .valueOf(
                            verbfeaturesenglisharabic.PASS
                        )
                    )
                }
                val mood: String = verb.getMood_kananumbers()
                when (mood) {
                    "IND" -> wordbdetail.put(
                        "mood", SpannableString .valueOf(
                            verbfeaturesenglisharabic.IND
                        )
                    )

                    "JUS" -> wordbdetail.put(
                        "mood", SpannableString .valueOf(
                            verbfeaturesenglisharabic.JUS
                        )
                    )

                    "SUBJ" -> wordbdetail.put(
                        "mood", SpannableString .valueOf(
                            verbfeaturesenglisharabic.SUBJ
                        )
                    )
                }
                wordbdetail.put("lemma", SpannableString .valueOf(verb.getLemma_a()))
                wordbdetail.put("root", SpannableString .valueOf(verb.getRoot_a()))
                //   wordbdetail.put("form", SpannableString .valueOf(verb.getForm() ));
                //  wordbdetail.put("wazan", SpannableString .valueOf(verb.getThulathibab() ));
            }
        }
        if (corpusSurahWord.size > 0) {
            if (corpusSurahWord.get(index).getWordcount() == 1) {
                if (corpusSurahWord.get(index).getRootaraone().length > 0) {
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagone())
                    )
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootaraone())
                    )
                } else {
                    wordbdetail.put("tag", SpannableString .valueOf("none"))
                }
            } else if (corpusSurahWord.get(index).getWordcount() == 2) {
                if (corpusSurahWord.get(index).getRootaraone().length > 0) {
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagone())
                    )
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootaraone())
                    )
                } else if (corpusSurahWord.get(index).getRootaratwo().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootaratwo())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagtwo())
                    )
                } else {
                    wordbdetail.put("tag", SpannableString .valueOf("none"))
                }
            } else if (corpusSurahWord.get(index).getWordcount() == 3) {
                if (corpusSurahWord.get(index).getRootaraone().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootaraone())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagone())
                    )
                } else if (corpusSurahWord.get(index).getRootaratwo().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootaratwo())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagtwo())
                    )
                } else if (corpusSurahWord.get(index).getRootarathree().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootarathree())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagthree())
                    )
                } else {
                    wordbdetail.put("tag", SpannableString .valueOf("none"))
                }
            } else if (corpusSurahWord.get(index).getWordcount() == 4) {
                if (corpusSurahWord.get(index).getRootaraone().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootaraone())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagone())
                    )
                } else if (corpusSurahWord.get(index).getRootaratwo().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootaratwo())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagtwo())
                    )
                } else if (corpusSurahWord.get(index).getRootarathree().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootarathree())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagthree())
                    )
                } else if (corpusSurahWord.get(index).getRootarafour().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootarafour())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagfour())
                    )
                } else {
                    wordbdetail.put("tag", SpannableString .valueOf("none"))
                }
            } else if (corpusSurahWord.get(index).getWordcount() == 5) {
                if (corpusSurahWord.get(index).getRootaraone().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootaraone())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagone())
                    )
                } else if (corpusSurahWord.get(index).getRootaratwo().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootaratwo())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagtwo())
                    )
                } else if (corpusSurahWord.get(index).getRootarathree().length > 0) {
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagthree())
                    )
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootarathree())
                    )
                } else if (corpusSurahWord.get(index).getRootarafour().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootarafour())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagfour())
                    )
                } else if (corpusSurahWord.get(index).getRootarafive().length > 0) {
                    wordbdetail.put(
                        "root",
                        SpannableString .valueOf(corpusSurahWord.get(index).getRootarafive())
                    )
                    wordbdetail.put(
                        "tag",
                        SpannableString .valueOf(corpusSurahWord.get(index).getTagfive())
                    )
                } else {
                    wordbdetail.put("tag", SpannableString .valueOf("none"))
                }
            } else {
                wordbdetail.put("tag", SpannableString .valueOf("none"))
            }
        }
    }

    private fun GetLemmArabicwordWordDetails(
        corpusSurahWord: ArrayList<NewCorpusExpandWbwPOJO>,
        wordbdetail: HashMap<String, SpannableString ?>
    ) {
        if (corpusSurahWord.get(index).getWordcount() == 1) {
            val tagone: String = corpusSurahWord.get(index).getTagone()
            val expandTagsone: String = QuranMorphologyDetails.Companion.expandTags(tagone)
            wordbdetail.put(
                "lemma",
                SpannableString .valueOf(corpusSurahWord.get(index).getLemaraone())
            )
            wordbdetail.put(
                "word",
                SpannableString .valueOf(corpusSurahWord.get(index).getAraone())
            )
            wordbdetail.put("worddetails", SpannableString .valueOf(expandTagsone))
        } else if (corpusSurahWord.get(index).getWordcount() == 2) {
            wordbdetail.put(
                "lemma",
                SpannableString .valueOf(
                    corpusSurahWord.get(index).getLemaraone() + corpusSurahWord.get(index)
                        .getLemaratwo()
                )
            )
            val araone: String = corpusSurahWord.get(index).getAraone()
            val aratwo: String = corpusSurahWord.get(index).getAratwo()
            val arabicspannable: SpannableString  = SpannableString (
                araone + aratwo
            )
            val tagtwo: String = corpusSurahWord.get(index).getTagtwo()
            val tagone: String = corpusSurahWord.get(index).getTagone()
            val expandTagsone: String = QuranMorphologyDetails.Companion.expandTags(tagone)
            val expandTagstwo: String = QuranMorphologyDetails.Companion.expandTags(tagtwo)
            val tagspannable: SpannableString  = SpannableString (
                (expandTagstwo + "|" +
                        expandTagsone)
            )
            val one: Int = corpusSurahWord.get(index).getAraone().length //2
            val two: Int = corpusSurahWord.get(index).getAratwo().length //3
            val secondend: Int = one + two
            val twotag: Int = expandTagsone.length //1
            val onetag: Int = expandTagstwo.length //3
            val secondendtag: Int = onetag + twotag
            arabicspannable.setSpan(
                ForegroundColorSpan(cyan),
                0,
                one,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            arabicspannable.setSpan(
                ForegroundColorSpan(yellow),
                one,
                secondend,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            tagspannable.setSpan(
                ForegroundColorSpan(yellow),
                0,
                onetag + 1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            tagspannable.setSpan(
                ForegroundColorSpan(cyan),
                onetag + 1,
                secondendtag + 1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            wordbdetail.put("word", arabicspannable)
            wordbdetail.put("worddetails", tagspannable)
        } else if (corpusSurahWord.get(index).getWordcount() == 3) {
            val sb: String  = String ()
            wordbdetail.put(
                "lemma", SpannableString .valueOf(
                    (corpusSurahWord.get(index).getLemaraone() + corpusSurahWord.get(index)
                        .getLemaratwo() +
                            corpusSurahWord.get(index).getLemrathree())
                )
            )
            val one: Int = corpusSurahWord.get(index).getAraone().length //2
            val two: Int = corpusSurahWord.get(index).getAratwo().length //3
            val three: Int = corpusSurahWord.get(index).getArathree().length //10
            val secondend: Int = one + two
            val thirdstart: Int = one + two
            val thirdend: Int = thirdstart + three
            val expandTagsone: String =
                QuranMorphologyDetails.Companion.expandTags(corpusSurahWord.get(index).getTagone())
            val expandTagstwo: String =
                QuranMorphologyDetails.Companion.expandTags(corpusSurahWord.get(index).getTagtwo())
            val expandTagsthree: String = QuranMorphologyDetails.Companion.expandTags(
                corpusSurahWord.get(index).getTagthree()
            )
            val tagone: Int = expandTagsone.length //4
            val tagtwo: Int = expandTagstwo.length //1
            val tagthree: Int = expandTagsthree.length //8
            val spannableString : SpannableString  = SpannableString (
                (corpusSurahWord.get(index).getAraone() + corpusSurahWord.get(index).getAratwo()
                        + corpusSurahWord.get(index).getArathree())
            )
            val tagspannable: SpannableString  = SpannableString (
                (expandTagsthree + "|" +
                        expandTagstwo + "|"
                        + expandTagsone)
            )
            spannableString .setSpan(
                ForegroundColorSpan(cyan),
                0,
                one,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannableString .setSpan(
                ForegroundColorSpan(yellow),
                one,
                secondend,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannableString .setSpan(
                ForegroundColorSpan(green),
                thirdstart,
                thirdend,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            sb.append(corpusSurahWord.get(index).getTagthree())
            sb.append("|")
            sb.append(corpusSurahWord.get(index).getTagtwo())
            sb.append("|")
            sb.append(corpusSurahWord.get(index).getTagone())
            // 0,tagthree
            // tagthree,tagtwo
            // tagtwo,tagone
            /*

tagspannable.subSequence(0,tagthree+1)
tagspannable.subSequence(tagthree+1,tagthree+tagtwo+2)
tagspannable.subSequence(tagthree+tagtwo+2,tagthree+tagtwo+tagone+2)
 */tagspannable.setSpan(
                ForegroundColorSpan(green),
                0,
                tagthree + 1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            tagspannable.setSpan(
                ForegroundColorSpan(yellow),
                tagthree + 1,
                tagthree + tagtwo + 2,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            tagspannable.setSpan(
                ForegroundColorSpan(cyan),
                tagthree + tagtwo + 2,
                tagthree + tagtwo + tagone + 2,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            wordbdetail.put("word", spannableString )
            //      wordbdetail.put("worddetails", sb.toString());
            wordbdetail.put("worddetails", tagspannable)
        } else if (corpusSurahWord.get(index).getWordcount() == 4) {
            val sb: String  = String ()
            wordbdetail.put(
                "lemma", SpannableString .valueOf(
                    (corpusSurahWord.get(index).getLemaraone() + corpusSurahWord.get(index)
                        .getLemaratwo() +
                            corpusSurahWord.get(index).getLemrathree())
                )
            )
            val one: Int = corpusSurahWord.get(index).getAraone().length //2
            val two: Int = corpusSurahWord.get(index).getAratwo().length //3
            val three: Int = corpusSurahWord.get(index).getArathree().length //5
            val four: Int = corpusSurahWord.get(index).getArafour().length //6
            val onetag: Int = corpusSurahWord.get(index).getTagone().length //1
            val twotag: Int = corpusSurahWord.get(index).getTagtwo().length //3
            val threetag: Int = corpusSurahWord.get(index).getTagthree().length //1
            val secondend: Int = one + two
            val thirdstart: Int = one + two
            val thirdend: Int = thirdstart + three
            val secondendtag: Int = onetag + twotag
            val thirdstarttag: Int = onetag + twotag + 1
            val thirdendtag: Int = thirdstarttag + threetag
            val expandTagsone: String =
                QuranMorphologyDetails.Companion.expandTags(corpusSurahWord.get(index).getTagone())
            val expandTagstwo: String =
                QuranMorphologyDetails.Companion.expandTags(corpusSurahWord.get(index).getTagtwo())
            val expandTagsthree: String = QuranMorphologyDetails.Companion.expandTags(
                corpusSurahWord.get(index).getTagthree()
            )
            val expandTagsfour: String =
                QuranMorphologyDetails.Companion.expandTags(corpusSurahWord.get(index).getTagfour())
            val spannableString : SpannableString  = SpannableString (
                (corpusSurahWord.get(index).getAraone() + corpusSurahWord.get(index).getAratwo()
                        + corpusSurahWord.get(index).getArathree() + corpusSurahWord.get(index)
                    .getArafour())
            )
            val tagspannable: SpannableString  = SpannableString (
                (expandTagsfour + "|" + expandTagsthree + "|" +
                        expandTagstwo + "|"
                        + expandTagsone)
            )
            spannableString .setSpan(
                ForegroundColorSpan(cyan),
                0,
                one,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannableString .setSpan(
                ForegroundColorSpan(yellow),
                one,
                secondend,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannableString .setSpan(
                ForegroundColorSpan(green),
                thirdstart,
                thirdend,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            spannableString .setSpan(
                ForegroundColorSpan(indigo),
                thirdend,
                thirdend + four,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            tagspannable.setSpan(
                ForegroundColorSpan(green),
                0,
                onetag + 1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            tagspannable.setSpan(
                ForegroundColorSpan(yellow),
                onetag + 1,
                secondendtag + 2,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            tagspannable.setSpan(
                ForegroundColorSpan(cyan),
                thirdstarttag,
                thirdendtag + 1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            sb.append(corpusSurahWord.get(index).getTagfour())
            sb.append("|")
            sb.append(corpusSurahWord.get(index).getTagthree())
            sb.append("|")
            sb.append(corpusSurahWord.get(index).getTagtwo())
            sb.append("|")
            sb.append(corpusSurahWord.get(index).getTagone())
            wordbdetail.put("word", spannableString )
            //      wordbdetail.put("worddetails", sb.toString());
            wordbdetail.put("worddetails", tagspannable)
        } else if (corpusSurahWord.get(index).getWordcount() == 5) {
            val sb: String  = String ()
            wordbdetail.put(
                "lemma", SpannableString .valueOf(
                    (corpusSurahWord.get(index).getLemaraone() + corpusSurahWord.get(index)
                        .getLemaratwo() +
                            corpusSurahWord.get(index).getLemrathree() + corpusSurahWord.get(index)
                        .getLemarafour() + corpusSurahWord.get(index).getLemarafive())
                )
            )
            sb.append(corpusSurahWord.get(index).getTagfive())
            sb.append("|")
            sb.append(corpusSurahWord.get(index).getTagfour())
            sb.append("|")
            sb.append(corpusSurahWord.get(index).getTagthree())
            sb.append("|")
            sb.append(corpusSurahWord.get(index).getTagtwo())
            sb.append("|")
            sb.append(corpusSurahWord.get(index).getTagone())
            wordbdetail.put(
                "word", SpannableString .valueOf(
                    (corpusSurahWord.get(index).getAraone() + corpusSurahWord.get(index)
                        .getAratwo() +
                            corpusSurahWord.get(index).getArathree() + corpusSurahWord.get(index)
                        .getArafour() + corpusSurahWord.get(index).getTagfive())
                )
            )
            wordbdetail.put("worddetails", SpannableString .valueOf(sb))
        }
    }

    private fun GetPronounDetails(
        corpusSurahWord: ArrayList<NewCorpusExpandWbwPOJO>,
        wordbdetail: HashMap<String, SpannableString ?>
    ) {
        if (corpusSurahWord.get(index).getWordcount() == 1) {
            if ((corpusSurahWord.get(index).getTagone() == "PRON")) {
                //   String[] parts = corpusSurahWord.get(index).getDetailsone().toString().split("\"|");
                val gendernumber: String = corpusSurahWord.get(index).getDetailsone()
                    .replace("^.*?(\\w+)\\W*$".toRegex(), "$1")
                println(gendernumber)
                // String gendernumber = parts[parts.length - 1];
                val  : String  =
                    QuranMorphologyDetails.Companion.getGenderNumberdetails(gendernumber)
                wordbdetail.put("PRON", SpannableString .valueOf( ))
            }
        } else if (corpusSurahWord.get(index).getWordcount() == 2) {
            if ((corpusSurahWord.get(index).getTagtwo() == "PRON")) {
                val gendernumber: String = corpusSurahWord.get(index).getDetailstwo()
                    .replace("^.*?(\\w+)\\W*$".toRegex(), "$1")
                //   String gendernumber = parts[parts.length - 1];
                val  : String  =
                    QuranMorphologyDetails.Companion.getGenderNumberdetails(gendernumber)
                wordbdetail.put("PRON", SpannableString .valueOf( ))
            }
        } else if (corpusSurahWord.get(index).getWordcount() == 3) {
            if ((corpusSurahWord.get(index).getTagthree() == "PRON")) {
                //   String[] parts = corpusSurahWord.get(index).getDetailsthree().toString().split("|");
                val gendernumber: String = corpusSurahWord.get(index).getDetailsthree()
                    .replace("^.*?(\\w+)\\W*$".toRegex(), "$1")
                //    String gendernumber = parts[parts.length - 1];
                val  : String  =
                    QuranMorphologyDetails.Companion.getGenderNumberdetails(gendernumber)
                wordbdetail.put("PRON", SpannableString .valueOf( ))
            }
        } else if (corpusSurahWord.get(index).getWordcount() == 4) {
            if ((corpusSurahWord.get(index).getTagfour() == "PRON")) {
                val parts: Array<String> =
                    corpusSurahWord.get(index).getDetailsfour().split("\\|PRON:".toRegex())
                        .dropLastWhile({ it.isEmpty() }).toTypedArray()
                val gendernumber: String = parts.get(parts.size - 1)
                val  : String  =
                    QuranMorphologyDetails.Companion.getGenderNumberdetails(gendernumber)
                wordbdetail.put("PRON", SpannableString .valueOf( ))
            }
        } else if (corpusSurahWord.get(index).getWordcount() == 5) {
            if ((corpusSurahWord.get(index).getTagfive() == "PRON")) {
                val parts: Array<String> =
                    corpusSurahWord.get(index).getDetailsfive().split("\\|".toRegex())
                        .dropLastWhile({ it.isEmpty() }).toTypedArray()
                val gendernumber: String = parts.get(parts.size - 1)
                val  : String  =
                    QuranMorphologyDetails.Companion.getGenderNumberdetails(gendernumber)
                wordbdetail.put("PRON", SpannableString .valueOf( ))
            }
        }
    }
}