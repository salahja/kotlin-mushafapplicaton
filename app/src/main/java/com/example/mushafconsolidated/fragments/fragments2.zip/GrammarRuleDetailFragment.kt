package com.example.mushafconsolidated.fragments

import GrammarRules
import android.content.ClipData
import android.os.Bundle
import android.view.DragEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.fragment.app.Fragment
import com.example.mushafconsolidated.R
import com.example.mushafconsolidated.databinding.FragmentGrammarruleDetailBinding
import com.example.mushafconsolidated.fragments.placeholderimport.PlaceholderContent
import com.google.android.material.appbar.CollapsingToolbarLayout

android.os.Bundleimport android.view.DragEventimport android.view.LayoutInflaterimport android.view.Viewimport android.view.View.OnDragListenerimport android.view.ViewGroupimport android.webkit.WebSettingsimport android.webkit.WebViewimport androidx.fragment.app.Fragmentimport com.example.mushafconsolidated.Activity.GrammarRuleDetailFragmentimport com.example.mushafconsolidated.Activity.placeholder.PlaceholderContentimport com.example.mushafconsolidated.Entities.GrammarRulesimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.databinding.FragmentGrammarruleDetailBindingimport com.google.android.material.appbar.CollapsingToolbarLayout
 
 
 
 
 


 
 
  
 
 
 
 
 
 

/**
 * A fragment representing a single GrammarRule detail screen.
 * This fragment is either contained in a [GrammarRuleListFragment]
 * in two-pane mode (on larger screen devices) or self-contained
 * on handsets.
 */
class GrammarRuleDetailFragment
/**
 * Mandatory empty constructor for the fragment manager to instantiate the
 * fragment (e.g. upon screen orientation changes).
 */
constructor() : Fragment() {
    /**
     * The placeholder content this fragment is presenting.
     */
    private var mItem: GrammarRules? = null
    private var mToolbarLayout: CollapsingToolbarLayout? = null
    private var mTextView: WebView? = null
    private val dragListener: View.OnDragListener =
        View.OnDragListener { v: View?, event: DragEvent ->
            if (event.getAction() == DragEvent.ACTION_DROP) {
                val clipDataItem: ClipData.Item = event.getClipData().getItemAt(0)
                mItem = PlaceholderContent.ITEM_MAP.get(clipDataItem.getText().toString())
                updateContent()
            }
            true
        }
    private var binding: FragmentGrammarruleDetailBinding? = null
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (getArguments()!!.containsKey(ARG_ITEM_ID)) {
            // Load the placeholder content specified by the fragment
            // arguments. In a real-world scenario, use a Loader
            // to load content from a content provider.
            mItem = PlaceholderContent.ITEM_MAP.get(
                getArguments()!!.getString(ARG_ITEM_ID)
            )
        }
    }

    public override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView: View = inflater.inflate(R.layout.fragment_grammarrule_detail, container, false)
        //   binding = FragmentGrammarruleDetailBinding.inflate(inflater, container, false);
        //  View rootView = binding.getRoot();
        mToolbarLayout = rootView.findViewById(R.id.toolbar_layout)
        mTextView = rootView.findViewById(R.id.grammarrule_detail)
        val webSettings: WebSettings = mTextView.getSettings()
        webSettings.setJavaScriptEnabled(true)
        //  mTextView.setInitialScale(1);
        //   mTextView.getSettings().setLoadWithOverviewMode(true);
        //    mTextView.getSettings().setUseWideViewPort(true);

        //      mTextView.getSettings().setBuiltInZoomControls(true);
        // Show the placeholder content as text in a TextView & in the toolbar if available.
        updateContent()
        rootView.setOnDragListener(dragListener)
        return rootView
    }

    public override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }

    private fun updateContent() {
        if (mItem != null) {
            mTextView!!.loadDataWithBaseURL(
                null,
                mItem!!.getDetailsrules(),
                "text/html",
                "utf-8",
                null
            )
            //   mTextView.setText(mItem.getDetailsrules());
            if (mToolbarLayout != null) {
                mToolbarLayout!!.setTitle(mItem!!.getWorddetails())
            }
        }
    }

    companion object {
        /**
         * The fragment argument representing the item ID that this fragment
         * represents.
         */
        val ARG_ITEM_ID: String = "item_id"
    }
}