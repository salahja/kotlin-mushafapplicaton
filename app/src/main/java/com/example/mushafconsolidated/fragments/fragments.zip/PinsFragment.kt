package com.example.mushafconsolidated.fragmentsimport

android.graphics.Colorimport android.os.Bundleimport android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroupimport androidx.coordinatorlayout.widget.CoordinatorLayoutimport androidx.fragment.app.Fragmentimport androidx.recyclerview.widget.ItemTouchHelperimport androidx.recyclerview.widget.LinearLayoutManagerimport androidx.recyclerview.widget.RecyclerViewimport com.example.Constantimport com.example.mushafconsolidated.Activity.QuranGrammarActimport com.example.mushafconsolidated.Adapters.BookmarksShowAdapterimport com.example.mushafconsolidated.Entities.BookMarksimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.Utilsimport com.example.mushafconsolidated.intrface.OnItemClickListenerimport com.example.utility.QuranGrammarApplicationimport com.example.utility.SwipeToDeleteCallbackimport com.google.android.material.snackbar.Snackbar
 

 

 

 
 
 
  
 
 
 

 


/**
 * Created by Dev. M. Hussein on 5/9/2017.
 */
class PinsFragment constructor() : Fragment() {
    var coordinatorLayout: CoordinatorLayout? = null
    var layoutManager: RecyclerView.LayoutManager? = null
    private var bookmarksShowAdapter: BookmarksShowAdapter? = null
    private var mRecview: RecyclerView? = null
    public override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //    View rootView = inflater.inflate(R.layout.activity_collection, container, false);
        val view: View = inflater.inflate(R.layout.fragment_bookmark, container, false)
        val utils: Utils = Utils(getActivity())
        val bookMarksNew: List<BookMarks> = Utils.Companion.getAllBookmarks("pins")
        val bookMarksNews: List<BookMarks> = Utils.Companion.getBookMarksNew()
        bookmarksShowAdapter = BookmarksShowAdapter(getActivity())
        mRecview = view.findViewById(R.id.recyclerViewAdapterTranslation)
        coordinatorLayout = view.findViewById(R.id.coordinatorLayoutbookmark)
        layoutManager = LinearLayoutManager(QuranGrammarApplication.appContext)
        mRecview.setLayoutManager(R.layoutManager)
        bookmarksShowAdapter!!.setBookMarkArrayList(bookMarksNew)
        mRecview.setAdapter(bookmarksShowAdapter)
        enableSwipeToDeleteAndUndo()
        return view
    }

    private fun enableSwipeToDeleteAndUndo() {
        val swipeToDeleteCallback: SwipeToDeleteCallback =
            object : SwipeToDeleteCallback(getActivity()) {
                public override fun onSwiped(viewHolder: RecyclerView.ViewHolder, i: Int) {
                    val position: Int = viewHolder.getAdapterPosition()
                    val item: BookMarks =
                        bookmarksShowAdapter!!.getBookMarkArrayList().get(position)
                    //   final int code = item.hashCode();
                    bookmarksShowAdapter!!.getItemId(position)
                    bookmarksShowAdapter!!.removeItem(position)
                    val snackbar: Snackbar = Snackbar
                        .make(
                            (coordinatorLayout)!!,
                            "Item was removed from the list.",
                            Snackbar.LENGTH_LONG
                        )
                    snackbar.setAction(
                        "UNDO",
                        View.OnClickListener({ view: View? -> mRecview!!.scrollToPosition(position) })
                    )
                    snackbar.setActionTextColor(Color.CYAN)
                    snackbar.show()
                    bookmarksShowAdapter!!.getBookChapterno()
                    //    Utils.deleteBookMarks(item);
                    Utils.Companion.deleteBookmark(item)
                }
            }
        val itemTouchhelper: ItemTouchHelper = ItemTouchHelper(swipeToDeleteCallback)
        itemTouchhelper.attachToRecyclerView(mRecview)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bookmarksShowAdapter!!.SetOnItemClickListener(OnItemClickListener({ v: View?, position: Int ->
            val bmark: BookMarks = bookmarksShowAdapter!!.getItem(position) as BookMarks
            val dataBundle: Bundle = Bundle()
            dataBundle.putInt(Constant.SURAH_ID, bmark.getChapterno().toInt())
            dataBundle.putInt(Constant.AYAHNUMBER, bmark.getVerseno().toInt())
            dataBundle.putString(Constant.SURAH_ARABIC_NAME, bmark.getSurahname())
            val readingintent: Intent = Intent(getActivity(), QuranGrammarAct::class.java)
            readingintent.putExtra(Constant.MUFRADATFRAGTAG, false)
            readingintent.putExtra(Constant.CHAPTER, bmark.getChapterno().toInt())
            readingintent.putExtra(Constant.AYAH_ID, bmark.getVerseno().toInt())
            readingintent.putExtra(Constant.CHAPTERORPART, true)
            readingintent.putExtra(Constant.SURAH_ARABIC_NAME, bmark.getSurahname())
            readingintent.putExtra(Constant.WBW, true)
            startActivity(readingintent)
        }))
    }
}