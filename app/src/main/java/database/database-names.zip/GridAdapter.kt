package database

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageView
import android.widget.TextView
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mushafconsolidated.R
import com.example.mushafconsolidated.R.*
import com.example.mushafconsolidated.databinding.ActivityArabicrootDetailBinding.inflate
import com.example.utility.QuranGrammarApplication
import database.entity.AllahNames
import org.sj.conjugator.interfaces.OnItemClickListener
import java.util.Locale

class GridAdapter(
    private val context: Context,
    names: ArrayList<AllahNames>,
    data: ArrayList<ImageItem>
) : RecyclerView.Adapter<GridAdapter.ViewHolder?>(), Filterable {
    private val mSearchText: CharSequence = ""
    private val names: List<AllahNames>
    private var namesfilter: List<AllahNames>
    var data: ArrayList<ImageItem>
    var rootcolor = 0
    var weaknesscolor = 0
    var wazancolor = 0
    var bookmarkpostion = 0
    var mItemClickListener: OnItemClickListener? = null

    //    private final Integer arabicTextColor;
    var mycontext: Context? = null
    private val mazeedregular = false
    private val bookChapterno = 0
    private val bookVerseno = 0
    private val ayahNumber: Int? = null
    private val urdu_font_selection: String? = null
    private val quran_arabic_font = 0
    private val urdu_font_size = 0
    private val arabic_font_selection: String? = null

    init {
        this.names = names
        namesfilter = names
        this.data = data
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {


        //      View view = LayoutInflater.from(parent.context!!).inflate(R.layout.sarfkabeercolumn, parent, false);
        val view: LayoutInflater? = LayoutInflater.from(parent.context)
        !!
        inflate(layout.nameimages, parent, false)
        //    View view = LayoutInflater.from(parent.context!!).inflate(R.layout.thulathisarfsagheer, parent, false);
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        //  final List sarf = sarfSagheer.get(position);
//        final String[] array = (String[]) sarfSagheer.get(position).toArray.get();
        val sharedPreferences: SharedPreferences =
            PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.context)
        !!
        val prefs: SharedPreferences =
            android.preference.PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.context)
        !!
        val fontCategory: String =
            sharedPreferences.getString("arabic_font_category", "me_quran.ttf")
        val prefArabicFontTypeface = Typeface.createFromAsset(QuranGrammarApplication.context)
        !!
        TODO(
            """
            |Cannot convert element: null
            |With text:
            |getAssets(), fontCategory
            """
        ).trimMargin()
        val fonts: String = prefs.getString("Arabic_Font_Size", "25")
        val arabicfontSize: Int = sharedPreferences.getInt("pref_font_arabic_key", 18)
        val translationfontsize: Int = sharedPreferences.getInt("pref_font_englsh_key", 18)
        //  String arabic_font_category = prefs.getString("arabic_font_category", "kitab.tff");
        val isNightmode: String = sharedPreferences.getString("themepref", "dark")
        val item: AllahNames = names[position]
        val mequran = Typeface.createFromAsset(QuranGrammarApplication.context)
        !!
        TODO(
            """
            |Cannot convert element: null
            |With text:
            |getAssets(), "Taha.ttf"
            """
        ).trimMargin()
        val arabicFontsize = Integer.valueOf(fonts)
        holder.imageView.setImageBitmap(data[position].image)
        names[position]
        holder.name.setText(item.getTrans())
        holder.meaning.setText(item.getMeaning())
        //  holder.name.setTypeface(prefArabicFontTypeface);
        // holder.name.setTextSize(arabicfontSize);
        holder.meaning.setTypeface(mequran)
        holder.meaning.setTextSize(translationfontsize.toFloat())


// holder.ivSurahIcon.setImageDrawable(drawable);
        //    holder.rulenumber.setTextSize(arabicFontsize);
    }

    fun getItem(position: Int): Any {
        return namesfilter[position]
    }

    override fun getItemCount(): Int {
        return namesfilter.size
    }

    fun SetOnItemClickListener(mItemClickListener: OnItemClickListener?) {
        this.mItemClickListener = mItemClickListener
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(charSequence: CharSequence): FilterResults {
                val charString = charSequence.toString()
                namesfilter = if (charString.isEmpty()) {
                    names
                } else {
                    val filteredList: MutableList<AllahNames> = ArrayList<AllahNames>()
                    for (details in names) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (details.getMeaning().lowercase(Locale.getDefault()).contains(
                                charString.lowercase(
                                    Locale.getDefault()
                                )
                            )
                        ) {
                            filteredList.add(details)
                        }
                    }
                    filteredList
                }
                val filterResults = FilterResults()
                filterResults.values = namesfilter
                return filterResults
            }

            override fun publishResults(charSequence: CharSequence, filterResults: FilterResults) {
                namesfilter = filterResults.values as ArrayList<AllahNames>
                notifyDataSetChanged()
            }
        }
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view),
        View.OnClickListener // current clickListerner
    {
        var imageView: ImageView
        var name: TextView
        var meaning: TextView

        init {
            imageView = view.findViewById<ImageView>(id.imageView)
            name = view.findViewById<TextView>(id.Names)
            meaning = view.findViewById<TextView>(id.meaning)
            view.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getLayoutPosition())
            }
        }
    }
}