package database

import android.graphics.Bitmap

class ImageItem(private var image: Bitmap, private var title: String) {
    fun getImage(): Bitmap {
        return image
    }

    fun setImage(image: Bitmap) {
        this.image = image
    }

    fun getTitle(): String {
        return title
    }

    fun setTitle(title: String) {
        this.title = title
    }
}