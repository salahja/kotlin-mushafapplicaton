package org.sj.verbConjugation.util;

public class SelectionInfo {
    private final int kov;
    public boolean trilateral;
    private boolean augmented;
    private boolean active;
    private Object root;
    private int augmentationFormulaNo;
    private String formulaText;
    private String verbText;

    public SelectionInfo(Object root, boolean trilateral, boolean augmented, int kov) {
        this.root = root;
        this.trilateral = trilateral;
        this.augmented = augmented;
        this.kov = kov;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isTrilateral() {
        return trilateral;
    }

    public void setTrilateral(boolean trilateral) {
        this.trilateral = trilateral;
    }

    public boolean isAugmented() {
        return augmented;
    }

    public void setAugmented(boolean augmented) {
        this.augmented = augmented;
    }

    public Object getRoot() {
        return root;
    }

    public void setRoot(Object root) {
        this.root = root;
    }

    public int getAugmentationFormulaNo() {
        return augmentationFormulaNo;
    }

    public void setAugmentationFormulaNo(int augmentationFormulaNo) {
        this.augmentationFormulaNo = augmentationFormulaNo;
    }

    public String getFormulaText() {
        return formulaText;
    }

    public void setFormulaText(String formulaText) {
        this.formulaText = formulaText;
    }

    public String getVerbText() {
        return verbText;
    }

    public void setVerbText(String verbText) {
        this.verbText = verbText;
    }

    public int getKov() {
        return kov;
    }
}
