package org.sj.nounConjugation.trilateral.unaugmented.modifier;

/**
 * <p>Title: Sarf Program</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: ALEXO</p>
 *
 * @author Haytham Mohtasseb Billah
 * @version 1.0
 */
public interface IUnaugmentedTrilateralNounModificationApplier {
    boolean isApplied(ConjugationResult conjugationResult);
}
