package org.sj.verbConjugation.trilateral.augmented.passive.past.formula;

import org.sj.verbConjugation.trilateral.augmented.AugmentedPastVerb;
import org.sj.verbConjugation.trilateral.augmented.AugmentedTrilateralRoot;
import org.sj.verbConjugation.util.ArabCharUtil;

/**
 * Title: Sarf
 * <p>
 * Description: ������ �������
 * <p>
 * Copyright: Copyright (c) 2006
 * <p>
 * Company:
 *
 * @author Haytham Mohtasseb Billah
 * @version 1.0
 */
public class AugmentedPastVerb4 extends AugmentedPastVerb {
    public AugmentedPastVerb4(AugmentedTrilateralRoot root, String lastDpa, String connectedPronoun) {
        super(root, lastDpa, connectedPronoun);
    }

    /**
     * form
     *
     * @return String
     * @todo Implement this sarf.trilingual.augmented.past.AugmentedPastVerb
     * method
     */
    public String form() {
        return "ان" + ArabCharUtil.SKOON + root.getC1() + ArabCharUtil.DAMMA + root.getC2() + ArabCharUtil.KASRA + root.getC3() + lastDpa + connectedPronoun;
    }
}
