package org.sj.verbConjugation.trilateral;

public interface TrilateralRoot {
    char getC1();

    char getC2();

    char getC3();
}
