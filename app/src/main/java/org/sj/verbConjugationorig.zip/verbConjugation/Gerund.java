package org.sj.verbConjugation;

/**
 * Title:
 * <p>
 * Copyright: Copyright (c) 2006
 * <p>
 * Company:
 *
 * @author not attributable
 * @version 1.0
 */
public class Gerund {
    private String symbol;
    private String value;

    public Gerund() {
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
