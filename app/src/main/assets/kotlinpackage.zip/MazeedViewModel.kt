package database.kotlinpackage

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.mushafconsolidated.DAO.QuranDao
import com.example.mushafconsolidated.Entities.QuranEntity
import kotlinx.coroutines.flow.Flow

/**
Please Note:
*Don't keep a reference to a Context that has a shorter lifecycle than your ViewModel! Examples are:
Activity, Fragment,View
* Keeping a reference can cause a memory leak, e.g. the ViewModel has a reference to a destroyed Activity!
* All these objects can be destroyed by the operating system and recreated
* when there's a configuration change, and this can happen many times during the lifecycle of a ViewModel.*/



    class MazeedViewModel(private val quran: QuranDao): ViewModel() {

        fun  quranbysurah(id: Int): Flow<List<QuranEntity>> = quran.quranbysurah(id)

}
class MazeedViewModelFactoryies(
    private val quran: QuranDao
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MazeedViewModel::class.java)) {
            val t = MazeedViewModel(quran) as T
            return t
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}