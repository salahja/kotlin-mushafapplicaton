package database.kotlinpackage


import com.example.mushafconsolidated.DAO.QuranDao


class MazeedInfoRepository(private val MazeedDao: QuranDao) {

    /** Please Note : Room executes all queries on a separate thread.
    Observed Flow will notify the observer when the data has changed.
    **/
    //var MazeedRoot: Flow<List<MazeedEntity>> = MazeedDao.getMazeedRoot(root = String())
  //  var MazeedRoot: Flow<List<MazeedEntity>> = MazeedDao.getAllmazeed()

/*
    suspend fun insert(userInfo: UserInfoEntity) {
        dataEntryDao.insert(userInfo)
    }

   suspend fun deleteById(u_id : Int){
        dataEntryDao.deleteById(u_id)
    }*/
}