package database.kotlinpackage

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

/**
 * If you are creating a new project by your own and you have a problem with the ViewModelFactory
 * please add this line in build.gradle Module level inside android{} block kotlinOptions {
freeCompilerArgs += [
"-Xjvm-default=all",
]
}
 */
class MazeedViewModelFactory(private val repository: MazeedInfoRepository): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MazeedViewModel::class.java)) {
         //   @Suppress("UNCHECKED_CAST")
         //   return MazeedViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}