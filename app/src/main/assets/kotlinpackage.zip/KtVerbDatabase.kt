package database.kotlinpackage

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.mushafconsolidated.DAO.QuranDao
import com.example.mushafconsolidated.Entities.ChaptersAnaEntity
import com.example.mushafconsolidated.Entities.QuranEntity
import com.example.mushafconsolidated.settingsimport.Constants
import com.example.mushafconsolidated.settingsimport.Constants.Companion.FILEPATH
import java.io.File

@Database(entities = [QuranEntity::class,ChaptersAnaEntity::class], version = 1, exportSchema = false)
abstract class KtVerbDatabase : RoomDatabase() {



    abstract fun  quranDao(): QuranDao
    companion object {
        val mainDatabase = File("$FILEPATH/${Constants.DATABASENAME}")
        // Singleton prevents multiple instances of database opening at the
        // same time.
        @Volatile
        private var INSTANCE: KtVerbDatabase? = null

        /** Note: When you modify the database schema,
        you'll need to update the version number and define a migration strategy.*/

        fun getDatabase(ctx: Context): KtVerbDatabase {
            return when (val temp = INSTANCE) {
                null -> synchronized(this) {
                    Room.databaseBuilder(
                        ctx.applicationContext, KtVerbDatabase::class.java,
                        "qurangrammar.db"
                    )
                        .createFromFile(mainDatabase)
                       .fallbackToDestructiveMigration()
                         .allowMainThreadQueries()
                        .fallbackToDestructiveMigration()
                        .build()
                }
                else -> temp
            }
        }
    }
}